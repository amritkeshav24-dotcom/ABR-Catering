import React, { useState, useEffect } from 'react';
import Navbar from './components/layout/Navbar';
import Footer from './components/layout/Footer';
import Hero from './components/sections/Hero';
import ServicesSection from './components/sections/ServicesSection';
import MenuSection from './components/sections/MenuSection';
import GalleryReelsSection from './components/sections/GalleryReelsSection';
import VenueMapSection from './components/sections/VenueMapSection';
import TestimonialsSection from './components/sections/TestimonialsSection';
import BookingModal from './components/booking/BookingModal';
import AIChatbotModal from './components/chat/AIChatbotModal';
import AdminDashboard from './components/admin/AdminDashboard';
import WhatsAppButton from './components/chat/WhatsAppButton';

import { MenuItem, CateringPackage, GalleryItem, CustomerReview, Booking } from './types';
import { INITIAL_MENU_ITEMS, INITIAL_PACKAGES, INITIAL_GALLERY, INITIAL_REVIEWS } from './data/initialData';

export default function App() {
  // Modals state
  const [bookingModalOpen, setBookingModalOpen] = useState(false);
  const [aiChatModalOpen, setAiChatModalOpen] = useState(false);
  const [adminModalOpen, setAdminModalOpen] = useState(false);

  // App Data
  const [menuItems, setMenuItems] = useState<MenuItem[]>(INITIAL_MENU_ITEMS);
  const [packages, setPackages] = useState<CateringPackage[]>(INITIAL_PACKAGES);
  const [galleryItems, setGalleryItems] = useState<GalleryItem[]>(INITIAL_GALLERY);
  const [reviews, setReviews] = useState<CustomerReview[]>(INITIAL_REVIEWS);

  // Preselected booking parameters
  const [preselectedPackage, setPreselectedPackage] = useState<CateringPackage | null>(null);
  const [preselectedMenuIds, setPreselectedMenuIds] = useState<string[]>([]);
  const [initialGuestCount, setInitialGuestCount] = useState<number>(150);

  // Fetch initial dynamic data from backend API
  useEffect(() => {
    const loadAppData = async () => {
      try {
        const [menuRes, galleryRes, reviewsRes] = await Promise.all([
          fetch('/api/menu').then((r) => r.json()),
          fetch('/api/gallery').then((r) => r.json()),
          fetch('/api/reviews').then((r) => r.json())
        ]);

        if (menuRes.items) setMenuItems(menuRes.items);
        if (menuRes.packages) setPackages(menuRes.packages);
        if (Array.isArray(galleryRes)) setGalleryItems(galleryRes);
        if (Array.isArray(reviewsRes)) setReviews(reviewsRes);
      } catch (err) {
        console.warn('API loading fallback to local seed data:', err);
      }
    };

    loadAppData();
  }, []);

  const handleOpenBookingWithPackage = (pkg: CateringPackage) => {
    setPreselectedPackage(pkg);
    setPreselectedMenuIds([]);
    setInitialGuestCount(pkg.minGuests || 150);
    setBookingModalOpen(true);
  };

  const handleOpenBookingWithMenu = (selectedIds: string[], guests: number) => {
    setPreselectedPackage(null);
    setPreselectedMenuIds(selectedIds);
    setInitialGuestCount(guests);
    setBookingModalOpen(true);
  };

  const handleAddReview = async (newRev: Partial<CustomerReview>) => {
    try {
      const res = await fetch('/api/reviews', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newRev)
      });
      const data = await res.json();
      setReviews((prev) => [data, ...prev]);
    } catch (err) {
      console.error(err);
      // Fallback local update
      const localRev: CustomerReview = {
        id: `rev_${Date.now()}`,
        customerName: newRev.customerName || 'Valued Guest',
        eventType: newRev.eventType || 'Event',
        rating: newRev.rating || 5,
        comment: newRev.comment || '',
        date: 'Just now',
        isApproved: true,
        isFeatured: false,
        verifiedEvent: true
      };
      setReviews((prev) => [localRev, ...prev]);
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] text-white font-sans selection:bg-[#D4AF37] selection:text-black">
      {/* Navigation */}
      <Navbar
        onOpenBooking={() => {
          setPreselectedPackage(null);
          setBookingModalOpen(true);
        }}
        onOpenAdmin={() => setAdminModalOpen(true)}
        onOpenChat={() => setAiChatModalOpen(true)}
      />

      {/* Main Page Sections */}
      <main>
        <Hero
          onOpenBooking={() => setBookingModalOpen(true)}
          onOpenChat={() => setAiChatModalOpen(true)}
        />

        <ServicesSection
          onOpenBooking={() => setBookingModalOpen(true)}
        />

        <MenuSection
          menuItems={menuItems}
          packages={packages}
          onOpenBookingWithPackage={handleOpenBookingWithPackage}
          onOpenBookingWithMenu={handleOpenBookingWithMenu}
        />

        <GalleryReelsSection galleryItems={galleryItems} />

        <VenueMapSection />

        <TestimonialsSection
          reviews={reviews}
          onAddReview={handleAddReview}
        />
      </main>

      {/* Footer */}
      <Footer
        onOpenBooking={() => setBookingModalOpen(true)}
        onOpenAdmin={() => setAdminModalOpen(true)}
      />

      {/* Modals & Floating Action Controls */}
      <BookingModal
        isOpen={bookingModalOpen}
        onClose={() => setBookingModalOpen(false)}
        preselectedPackage={preselectedPackage}
        preselectedMenuIds={preselectedMenuIds}
        initialGuestCount={initialGuestCount}
      />

      <AIChatbotModal
        isOpen={aiChatModalOpen}
        onClose={() => setAiChatModalOpen(false)}
        onOpenBooking={() => {
          setAiChatModalOpen(false);
          setBookingModalOpen(true);
        }}
      />

      <AdminDashboard
        isOpen={adminModalOpen}
        onClose={() => setAdminModalOpen(false)}
      />

      <WhatsAppButton />
    </div>
  );
}
