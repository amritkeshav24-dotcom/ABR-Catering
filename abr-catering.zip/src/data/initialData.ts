import { MenuItem, CateringPackage, Booking, GalleryItem, CustomerReview } from '../types';

export const INITIAL_MENU_ITEMS: MenuItem[] = [
  {
    id: 'm1',
    name: 'Zafrani Galouti Kebab with Sheermal',
    description: 'Melt-in-mouth minced lamb patties infused with 32 royal spices, served on mini saffron-infused artisan breads.',
    pricePerPlate: 320,
    category: 'Starters',
    dietary: 'non-veg',
    imageUrl: 'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?auto=format&fit=crop&w=800&q=80',
    isPopular: true,
    isSpecialty: true,
    spiciness: 2
  },
  {
    id: 'm2',
    name: 'Royal Truffle Paneer Tikka',
    description: 'Fresh cottage cheese marinated in hung curd, black truffle oil, and crushed yellow chili, grilled in clay tandoor.',
    pricePerPlate: 260,
    category: 'Starters',
    dietary: 'veg',
    imageUrl: 'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?auto=format&fit=crop&w=800&q=80',
    isPopular: true,
    spiciness: 1
  },
  {
    id: 'm3',
    name: 'Avocado & Pomegranate Dahi Puri',
    description: 'Crispy semolina spheres filled with spiced Hass avocado, chilled sweetened yogurt, mint emulsion, and gold leaf.',
    pricePerPlate: 220,
    category: 'Starters',
    dietary: 'veg',
    imageUrl: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=800&q=80',
    isSpecialty: true,
    spiciness: 1
  },
  {
    id: 'm4',
    name: 'Dum Pukht Shahi Awadhi Biryani',
    description: 'Aromatic long-grain basmati rice and tender lamb cooked sealed under dough dough dum style with kewra & saffron.',
    pricePerPlate: 480,
    category: 'Royal Main Course',
    dietary: 'non-veg',
    imageUrl: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80',
    isPopular: true,
    isSpecialty: true,
    spiciness: 2
  },
  {
    id: 'm5',
    name: 'Dal Makhani Gold Velvet',
    description: 'Black lentils slow-simmered for 24 hours over wood charcoal, finished with artisanal butter and cream.',
    pricePerPlate: 280,
    category: 'Royal Main Course',
    dietary: 'veg',
    imageUrl: 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80',
    isPopular: true,
    spiciness: 1
  },
  {
    id: 'm6',
    name: 'Nizam-Style Murgh Makhani',
    description: 'Char-broiled boneless chicken cooked in a rich velvet tomato gravy infused with green cardamom & kasoori methi.',
    pricePerPlate: 380,
    category: 'Royal Main Course',
    dietary: 'non-veg',
    imageUrl: 'https://images.unsplash.com/photo-1588166524941-3bf61a9c41db?auto=format&fit=crop&w=800&q=80',
    isPopular: true,
    spiciness: 2
  },
  {
    id: 'm7',
    name: 'Molecular Live Chaat Station',
    description: 'Interactive counter featuring nitrogen-chilled bhel, smoked palak patta chaat, and artisan tamarind pearls.',
    pricePerPlate: 250,
    category: 'Live Counters',
    dietary: 'veg',
    imageUrl: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=800&q=80',
    isSpecialty: true,
    spiciness: 1
  },
  {
    id: 'm8',
    name: 'Live Wood-Fired Neapolitan Pizza Bar',
    description: 'Hand-stretched sourdough pizzas topped with fresh buffalo mozzarella, San Marzano tomatoes, and truffle glaze.',
    pricePerPlate: 350,
    category: 'Live Counters',
    dietary: 'veg',
    imageUrl: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=800&q=80',
    isPopular: true,
    spiciness: 1
  },
  {
    id: 'm9',
    name: 'Gold Leaf Shahi Tukda & Rabri',
    description: 'Pan-fried ghee bread soaked in saffron syrup, layered with dense thickened milk rabri and 24K edible gold foil.',
    pricePerPlate: 220,
    category: 'Desserts & Sweets',
    dietary: 'veg',
    imageUrl: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=800&q=80',
    isPopular: true,
    isSpecialty: true
  },
  {
    id: 'm10',
    name: 'Live Nitrogen Ice Cream & Churros Counter',
    description: 'Custom flash-frozen artisanal gelato crafted with liquid nitrogen before guests, served with warm cinnamon churros.',
    pricePerPlate: 290,
    category: 'Desserts & Sweets',
    dietary: 'veg',
    imageUrl: 'https://images.unsplash.com/photo-1570197788417-0e82375c9371?auto=format&fit=crop&w=800&q=80',
    isSpecialty: true
  },
  {
    id: 'm11',
    name: 'Saffron Smoked Smoked Rose Elixir',
    description: 'Chilled signature welcome drink with organic Kashmiri rose petals, crushed pistachios, and saffron mist.',
    pricePerPlate: 150,
    category: 'Mocktails & Beverages',
    dietary: 'vegan',
    imageUrl: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=800&q=80',
    isPopular: true
  }
];

export const INITIAL_PACKAGES: CateringPackage[] = [
  {
    id: 'pkg-executive',
    name: 'Classic Luxury Package',
    tagline: 'Ideal for Corporate Galas, Anniversaries & Intimate Gatherings',
    pricePerPlate: 950,
    minGuests: 50,
    includedItemsCount: { starters: 4, mains: 5, liveCounters: 1, desserts: 2, beverages: 2 },
    highlights: ['Welcome Drinks', '4 Pass-around Starters', 'Buffet Layout with Warmers', 'Professional Uniformed Service Staff'],
    recommendedFor: 'Corporate Events & Parties (50 - 200 Guests)',
    isPopular: false
  },
  {
    id: 'pkg-royal',
    name: 'Royal Heritage Feast',
    tagline: 'Our Signature Package for Grand Weddings & Prestigious Receptions',
    pricePerPlate: 1450,
    minGuests: 100,
    includedItemsCount: { starters: 6, mains: 8, liveCounters: 3, desserts: 4, beverages: 3 },
    highlights: ['24K Gold Leaf Dessert Finish', '3 Live Interactive Food Counters', 'Custom Menu Tasting Session', 'VIP Plated Table Service Options', 'Dedicated Event Catering Manager'],
    recommendedFor: 'Grand Weddings & Big Celebrations (100 - 1500+ Guests)',
    isPopular: true
  },
  {
    id: 'pkg-imperial',
    name: 'Imperial Destination Dining',
    tagline: 'Bespoke Ultra-Luxury Catering with World Cuisines & Michelin-Standard Plating',
    pricePerPlate: 2200,
    minGuests: 75,
    includedItemsCount: { starters: 8, mains: 10, liveCounters: 5, desserts: 5, beverages: 4 },
    highlights: ['Executive Master Chef Presence', '5 Global Live Chef Counters', 'Imported Artisanal Glassware & Cutlery', 'Sommelier Mocktail Pairing', 'Zero-Wait White-Glove Butler Service'],
    recommendedFor: 'High-Profile Luxury Weddings & Destination Feasts',
    isPopular: false
  }
];

export const INITIAL_BOOKINGS: Booking[] = [
  {
    id: 'ABR-2026-8801',
    customerName: 'Rajesh & Simran Kapoor',
    email: 'rajesh.kapoor@example.com',
    phone: '+91 98201 45890',
    eventType: 'Wedding',
    eventDate: '2026-08-25',
    guestCount: 350,
    venueLocation: 'The Oberoi Grand Ballroom, New Delhi',
    selectedPackageId: 'pkg-royal',
    totalEstimate: 507500,
    depositAmount: 50000,
    status: 'CONFIRMED',
    paymentStatus: 'DEPOSIT_PAID',
    razorpayOrderId: 'order_P9K8231ABR',
    razorpayPaymentId: 'pay_P9K8231ABR_01',
    specialInstructions: 'Require 2 separate Jain vegetarian live counters and low spice options for international guests.',
    createdAt: '2026-07-28T10:15:00Z'
  },
  {
    id: 'ABR-2026-8802',
    customerName: 'Ananya Singhania (TechCorp Gala)',
    email: 'ananya@techcorp.in',
    phone: '+91 99302 11200',
    eventType: 'Corporate Gala',
    eventDate: '2026-09-12',
    guestCount: 180,
    venueLocation: 'Taj Lands End, Mumbai',
    selectedPackageId: 'pkg-executive',
    totalEstimate: 171000,
    depositAmount: 25000,
    status: 'PENDING',
    paymentStatus: 'PENDING',
    specialInstructions: 'Focus on finger foods and interactive live mocktail counter.',
    createdAt: '2026-07-30T14:22:00Z'
  }
];

export const INITIAL_GALLERY: GalleryItem[] = [
  {
    id: 'g1',
    title: 'The Kapoor Royal Wedding Banquet',
    category: 'Weddings',
    mediaType: 'IMAGE',
    mediaUrl: 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1200&q=80',
    thumbnailUrl: 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=600&q=80',
    caption: 'A 500-guest royal banquet featuring 40+ dishes and live brass chafing arrangements.',
    likesCount: 142
  },
  {
    id: 'g2',
    title: 'Precision Plating: Zafrani Galouti',
    category: 'Plating Art',
    mediaType: 'IMAGE',
    mediaUrl: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=1200&q=80',
    thumbnailUrl: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=600&q=80',
    caption: 'Gold leaf garnished Galouti kebab served with saffron infused reduction.',
    likesCount: 210
  },
  {
    id: 'r1',
    title: 'Behind the Scenes: Saffron Dum Biryani Cooking',
    category: 'Reels',
    mediaType: 'VIDEO',
    mediaUrl: 'https://assets.mixkit.co/videos/preview/mixkit-chef-plating-a-gourmet-dish-in-a-restaurant-41484-large.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=600&q=80',
    caption: 'Unsealing the clay handi dough dum biryani live at Taj Palace event! Smell the saffron aroma! 👑',
    likesCount: 1250,
    duration: '0:32',
    aspectRatio: 'portrait'
  },
  {
    id: 'r2',
    title: 'Interactive Molecular Chaat Nitro Bar',
    category: 'Reels',
    mediaType: 'VIDEO',
    mediaUrl: 'https://assets.mixkit.co/videos/preview/mixkit-bartender-making-a-cocktail-at-the-bar-41485-large.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=600&q=80',
    caption: 'Guests raving over our liquid nitrogen palak patta chaat counter! ✨',
    likesCount: 890,
    duration: '0:25',
    aspectRatio: 'portrait'
  }
];

export const INITIAL_REVIEWS: CustomerReview[] = [
  {
    id: 'rev1',
    customerName: 'Siddharth & Priya Malhotra',
    eventType: 'Royal Wedding (500 Guests)',
    rating: 5,
    comment: 'ABR Catering transformed our wedding reception into a regal feast. Our guests are still talking about the Zafrani Biryani and 24K Shahi Tukda! The staff efficiency was unmatched.',
    date: 'July 2026',
    isApproved: true,
    isFeatured: true,
    verifiedEvent: true,
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'
  },
  {
    id: 'rev2',
    customerName: 'Vikram Mehta (VP, Global Financial)',
    eventType: 'Annual Leadership Gala',
    rating: 5,
    comment: 'The precision, hygiene, and presentation delivered by ABR Catering for our 300 corporate delegates was world-class. The AI Menu Planner suggested a flawless fusion menu.',
    date: 'June 2026',
    isApproved: true,
    isFeatured: true,
    verifiedEvent: true,
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80'
  },
  {
    id: 'rev3',
    customerName: 'Dr. Sunita Deshmukh',
    eventType: '25th Wedding Anniversary',
    rating: 5,
    comment: 'From live nitrogen dessert bars to authentic Awadhi starters, ABR made our silver jubilee unforgettable. Highly recommend their Royal Heritage package!',
    date: 'May 2026',
    isApproved: true,
    isFeatured: true,
    verifiedEvent: true,
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80'
  }
];
