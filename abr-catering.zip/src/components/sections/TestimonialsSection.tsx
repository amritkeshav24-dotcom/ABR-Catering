import React, { useState } from 'react';
import { CustomerReview } from '../../types';
import { Star, MessageSquareQuote, CheckCircle, Plus, Send, X, Sparkles } from 'lucide-react';

interface TestimonialsSectionProps {
  reviews: CustomerReview[];
  onAddReview: (review: Partial<CustomerReview>) => void;
}

export default function TestimonialsSection({ reviews, onAddReview }: TestimonialsSectionProps) {
  const [modalOpen, setModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [eventType, setEventType] = useState('Royal Wedding');
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !comment) return;
    onAddReview({
      customerName: name,
      eventType,
      rating,
      comment
    });
    setName('');
    setComment('');
    setModalOpen(false);
  };

  return (
    <section id="reviews" className="py-24 bg-neutral-950 relative border-t border-amber-500/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold uppercase tracking-wider mb-4">
            <MessageSquareQuote className="w-3.5 h-3.5" />
            <span>Verified Customer Reviews</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-white mb-6">
            Words From Our <span className="gold-gradient-text">Royal Hosts</span>
          </h2>
          <p className="text-gray-400 text-base leading-relaxed">
            Read authentic reviews from host families, corporate executives, and wedding planners.
          </p>

          <button
            onClick={() => setModalOpen(true)}
            className="mt-6 px-6 py-2.5 rounded-full bg-neutral-900 border border-amber-500/30 text-amber-300 hover:bg-amber-500 hover:text-black font-semibold text-xs uppercase tracking-wider transition-all inline-flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            <span>Leave a Review</span>
          </button>
        </div>

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {reviews.map((rev) => (
            <div
              key={rev.id}
              className="rounded-2xl glass-card p-8 flex flex-col justify-between space-y-6 border border-amber-500/20 hover:border-amber-400/50 transition-all"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-4 h-4 ${
                          i < rev.rating
                            ? 'text-amber-400 fill-amber-400'
                            : 'text-gray-600'
                        }`}
                      />
                    ))}
                  </div>
                  {rev.verifiedEvent && (
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2.5 py-1 rounded-full">
                      <CheckCircle className="w-3 h-3" /> Verified Event
                    </span>
                  )}
                </div>

                <p className="text-sm text-gray-300 leading-relaxed font-light italic">
                  "{rev.comment}"
                </p>
              </div>

              <div className="pt-4 border-t border-white/10 flex items-center gap-3">
                {rev.avatarUrl ? (
                  <img
                    src={rev.avatarUrl}
                    alt={rev.customerName}
                    className="w-10 h-10 rounded-full object-cover border border-amber-500/40"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-amber-500/20 border border-amber-400/40 flex items-center justify-center font-bold text-amber-300">
                    {rev.customerName.charAt(0)}
                  </div>
                )}
                <div>
                  <h4 className="font-serif font-bold text-sm text-white">{rev.customerName}</h4>
                  <span className="text-[11px] text-amber-400/80 block">{rev.eventType}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Review Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-lg rounded-2xl glass-card p-6 border border-amber-500/40 space-y-6">
            <div className="flex justify-between items-center border-b border-amber-500/20 pb-4">
              <h3 className="font-serif font-bold text-xl text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-400" />
                Share Your Culinary Experience
              </h3>
              <button
                onClick={() => setModalOpen(false)}
                className="text-gray-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-gray-300 block mb-1">Your Full Name:</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Anish & Ritu Sharma"
                  className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-amber-500/20 text-white text-xs"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-gray-300 block mb-1">Event Type:</label>
                <select
                  value={eventType}
                  onChange={(e) => setEventType(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-amber-500/20 text-white text-xs"
                >
                  <option value="Royal Wedding">Royal Wedding</option>
                  <option value="Corporate Gala">Corporate Gala</option>
                  <option value="Anniversary Feast">Anniversary Feast</option>
                  <option value="Private Dining">Private Dining</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-semibold text-gray-300 block mb-1">Rating:</label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRating(star)}
                      className="p-1"
                    >
                      <Star
                        className={`w-6 h-6 ${
                          star <= rating
                            ? 'text-amber-400 fill-amber-400'
                            : 'text-gray-600'
                        }`}
                      />
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-gray-300 block mb-1">Your Feedback:</label>
                <textarea
                  rows={3}
                  required
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder="Tell us about the food quality, staff efficiency, and presentation..."
                  className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-amber-500/20 text-white text-xs"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-600 text-black font-bold text-xs uppercase tracking-wider"
              >
                Submit Review
              </button>
            </form>
          </div>
        </div>
      )}
    </section>
  );
}
