import React, { useState } from 'react';
import { motion } from 'motion/react';
import { MenuItem, CateringPackage, MealCategory, DietaryType } from '../../types';
import { Utensils, Sparkles, Plus, Check, Flame, Users, Calculator, Info, ShieldCheck } from 'lucide-react';

interface MenuSectionProps {
  menuItems: MenuItem[];
  packages: CateringPackage[];
  onOpenBookingWithPackage?: (pkg: CateringPackage) => void;
  onOpenBookingWithMenu?: (selectedIds: string[], guestCount: number) => void;
}

export default function MenuSection({
  menuItems,
  packages,
  onOpenBookingWithPackage,
  onOpenBookingWithMenu,
}: MenuSectionProps) {
  const [activeTab, setActiveTab] = useState<'menu' | 'packages'>('menu');
  const [selectedCategory, setSelectedCategory] = useState<MealCategory | 'All'>('All');
  const [selectedDietary, setSelectedDietary] = useState<DietaryType | 'all'>('all');
  const [selectedItemIds, setSelectedItemIds] = useState<string[]>(['m1', 'm4', 'm5', 'm9']);
  const [estimatedGuests, setEstimatedGuests] = useState<number>(150);

  const categories: (MealCategory | 'All')[] = [
    'All',
    'Starters',
    'Royal Main Course',
    'Live Counters',
    'Desserts & Sweets',
    'Mocktails & Beverages',
  ];

  const filteredMenuItems = menuItems.filter((item) => {
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    const matchesDietary = selectedDietary === 'all' || item.dietary === selectedDietary;
    return matchesCategory && matchesDietary;
  });

  const toggleItemSelection = (id: string) => {
    setSelectedItemIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const selectedObjects = menuItems.filter((m) => selectedItemIds.includes(m.id));
  const customPerPlateTotal = selectedObjects.reduce((sum, item) => sum + item.pricePerPlate, 0);
  const customGrandTotal = customPerPlateTotal * estimatedGuests;

  return (
    <section id="menu" className="py-24 bg-[#050505] relative overflow-hidden border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-[#D4AF37]/30 text-[#D4AF37] text-xs font-semibold uppercase tracking-widest mb-4">
            <Utensils className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>Interactive Royal Menu & Packages</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-serif text-white mb-6">
            A Royal Feast <span className="text-[#D4AF37] italic">Tailored To Perfection</span>
          </h2>
          <p className="text-gray-400 text-base leading-relaxed">
            Explore our artisanal menu delicacies or choose a curated royal package. Customize your menu and instantly estimate your event catering budget.
          </p>

          {/* Tab Toggle: Individual Dishes vs Curated Packages */}
          <div className="inline-flex p-1 bg-neutral-900 border border-white/10 mt-8">
            <button
              onClick={() => setActiveTab('menu')}
              className={`px-6 py-2.5 text-xs font-bold uppercase tracking-widest transition-all ${
                activeTab === 'menu'
                  ? 'bg-[#D4AF37] text-black shadow-lg'
                  : 'text-gray-400 hover:text-white'
              }`}
              id="menu-tab-individual-btn"
            >
              Interactive Menu Builder
            </button>
            <button
              onClick={() => setActiveTab('packages')}
              className={`px-6 py-2.5 text-xs font-bold uppercase tracking-widest transition-all ${
                activeTab === 'packages'
                  ? 'bg-[#D4AF37] text-black shadow-lg'
                  : 'text-gray-400 hover:text-white'
              }`}
              id="menu-tab-packages-btn"
            >
              Curated Royal Packages
            </button>
          </div>
        </div>

        {activeTab === 'menu' ? (
          <div>
            {/* Filters bar */}
            <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-8 p-4 rounded-2xl glass-card">
              {/* Categories */}
              <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto pb-2 md:pb-0 scrollbar-none">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                      selectedCategory === cat
                        ? 'bg-amber-500/20 border border-amber-400 text-amber-300'
                        : 'bg-neutral-900 text-gray-400 border border-transparent hover:text-white'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              {/* Dietary filters */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setSelectedDietary('all')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                    selectedDietary === 'all' ? 'bg-white/10 text-amber-300' : 'text-gray-500 hover:text-gray-300'
                  }`}
                >
                  All
                </button>
                <button
                  onClick={() => setSelectedDietary('veg')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                    selectedDietary === 'veg' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'text-gray-400 hover:text-emerald-400'
                  }`}
                >
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  Pure Veg
                </button>
                <button
                  onClick={() => setSelectedDietary('non-veg')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                    selectedDietary === 'non-veg' ? 'bg-red-500/20 text-red-300 border border-red-500/40' : 'text-gray-400 hover:text-red-400'
                  }`}
                >
                  <span className="w-2 h-2 rounded-full bg-red-500" />
                  Non-Veg
                </button>
              </div>
            </div>

            {/* Menu Items Grid & Side Estimator */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Menu Grid */}
              <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-6">
                {filteredMenuItems.map((item) => {
                  const isSelected = selectedItemIds.includes(item.id);
                  return (
                    <div
                      key={item.id}
                      className={`relative rounded-2xl glass-card overflow-hidden transition-all duration-300 flex flex-col justify-between ${
                        isSelected ? 'border-amber-400/80 shadow-[0_0_20px_rgba(212,175,55,0.2)]' : 'hover:border-amber-500/30'
                      }`}
                    >
                      <div className="relative h-44 w-full overflow-hidden">
                        <img
                          src={item.imageUrl}
                          alt={item.name}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-transparent to-transparent" />
                        
                        <div className="absolute top-3 left-3 flex gap-2">
                          <span
                            className={`px-2.5 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider ${
                              item.dietary === 'veg'
                                ? 'bg-emerald-900/90 text-emerald-300 border border-emerald-500/40'
                                : 'bg-red-900/90 text-red-300 border border-red-500/40'
                            }`}
                          >
                            {item.dietary}
                          </span>
                          {item.isSpecialty && (
                            <span className="px-2.5 py-1 rounded-md bg-amber-500 text-black font-bold text-[10px] uppercase">
                              Chef Specialty
                            </span>
                          )}
                        </div>

                        <span className="absolute bottom-3 right-3 font-serif font-bold text-lg text-amber-300 bg-neutral-950/80 px-3 py-1 rounded-lg backdrop-blur-md border border-amber-500/30">
                          ₹{item.pricePerPlate} <span className="text-[10px] font-sans font-normal text-gray-400">/plate</span>
                        </span>
                      </div>

                      <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                        <div>
                          <h4 className="font-serif font-bold text-lg text-white mb-1">
                            {item.name}
                          </h4>
                          <p className="text-xs text-gray-400 leading-relaxed font-light line-clamp-2">
                            {item.description}
                          </p>
                        </div>

                        <button
                          onClick={() => toggleItemSelection(item.id)}
                          className={`w-full py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 ${
                            isSelected
                              ? 'bg-amber-500 text-black'
                              : 'bg-neutral-900 border border-amber-500/30 text-amber-300 hover:bg-amber-500/20'
                          }`}
                        >
                          {isSelected ? (
                            <>
                              <Check className="w-4 h-4 stroke-[3]" />
                              <span>Added to Menu ({selectedItemIds.length})</span>
                            </>
                          ) : (
                            <>
                              <Plus className="w-4 h-4" />
                              <span>Add to Custom Menu</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Side Plate Calculator */}
              <div className="lg:col-span-1">
                <div className="sticky top-28 p-6 rounded-2xl glass-card space-y-6 border border-amber-500/30 shadow-2xl">
                  <div className="flex items-center gap-3 border-b border-amber-500/20 pb-4">
                    <div className="w-10 h-10 rounded-xl bg-amber-500/20 flex items-center justify-center text-amber-400">
                      <Calculator className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-serif font-bold text-lg text-white">
                        Live Catering Estimator
                      </h3>
                      <p className="text-xs text-gray-400">
                        Customize menu & instant guest count quote
                      </p>
                    </div>
                  </div>

                  {/* Guest count slider */}
                  <div className="space-y-3">
                    <div className="flex justify-between items-center text-xs font-semibold text-gray-300">
                      <span>Guest Count:</span>
                      <span className="text-amber-300 font-serif font-bold text-base">{estimatedGuests} Guests</span>
                    </div>
                    <input
                      type="range"
                      min="50"
                      max="1000"
                      step="25"
                      value={estimatedGuests}
                      onChange={(e) => setEstimatedGuests(Number(e.target.value))}
                      className="w-full accent-amber-500 cursor-pointer"
                    />
                    <div className="flex justify-between text-[10px] text-gray-500">
                      <span>50 Guests</span>
                      <span>500 Guests</span>
                      <span>1000+ Guests</span>
                    </div>
                  </div>

                  {/* Selected items breakdown */}
                  <div className="space-y-2 pt-2 border-t border-white/10 max-h-48 overflow-y-auto pr-1">
                    <span className="text-xs font-semibold text-gray-400">Selected Menu Items ({selectedObjects.length}):</span>
                    {selectedObjects.length === 0 ? (
                      <p className="text-xs text-gray-500 italic">No dishes selected yet. Click "+ Add to Custom Menu" on dishes.</p>
                    ) : (
                      selectedObjects.map((so) => (
                        <div key={so.id} className="flex items-center justify-between text-xs py-1 text-gray-300 border-b border-white/5">
                          <span className="truncate pr-2">{so.name}</span>
                          <span className="font-semibold text-amber-300 shrink-0">₹{so.pricePerPlate}</span>
                        </div>
                      ))
                    )}
                  </div>

                  {/* Price Summary */}
                  <div className="p-4 rounded-xl bg-neutral-900 border border-amber-500/20 space-y-2">
                    <div className="flex justify-between text-xs text-gray-400">
                      <span>Estimated Menu Price / Plate:</span>
                      <span className="font-semibold text-white">₹{customPerPlateTotal}</span>
                    </div>
                    <div className="flex justify-between text-xs text-gray-400">
                      <span>Guest Volume ({estimatedGuests}):</span>
                      <span className="font-semibold text-white">x {estimatedGuests}</span>
                    </div>
                    <div className="pt-2 border-t border-white/10 flex justify-between items-center">
                      <span className="text-sm font-bold text-amber-300">Estimated Total:</span>
                      <span className="font-serif font-bold text-xl text-amber-400">
                        ₹{customGrandTotal.toLocaleString('en-IN')}
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => onOpenBookingWithMenu && onOpenBookingWithMenu(selectedItemIds, estimatedGuests)}
                    disabled={selectedItemIds.length === 0}
                    className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-600 text-black font-bold text-xs uppercase tracking-wider shadow-[0_0_20px_rgba(212,175,55,0.3)] hover:brightness-110 disabled:opacity-50 transition-all"
                  >
                    Proceed with Custom Selection
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* Packages View */
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {packages.map((pkg) => (
              <motion.div
                key={pkg.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className={`rounded-2xl glass-card p-8 flex flex-col justify-between relative ${
                  pkg.isPopular ? 'border-amber-400 shadow-[0_0_30px_rgba(212,175,55,0.3)]' : 'border-amber-500/20'
                }`}
              >
                {pkg.isPopular && (
                  <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-amber-500 text-black font-bold text-xs uppercase tracking-wider shadow-lg">
                    Most Popular Choice
                  </span>
                )}

                <div className="space-y-6">
                  <div>
                    <h3 className="font-serif font-bold text-2xl text-white mb-2">{pkg.name}</h3>
                    <p className="text-xs text-amber-200/80 italic">{pkg.tagline}</p>
                  </div>

                  <div className="p-4 rounded-xl bg-neutral-900 border border-amber-500/20 text-center">
                    <span className="font-serif font-bold text-4xl gold-gradient-text">
                      ₹{pkg.pricePerPlate}
                    </span>
                    <span className="text-xs text-gray-400 block mt-1">per plate (Min {pkg.minGuests} guests)</span>
                  </div>

                  <div className="space-y-3">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400">
                      Included Course Breakdown:
                    </h4>
                    <div className="grid grid-cols-2 gap-2 text-xs text-gray-300">
                      <div className="p-2 bg-neutral-900/60 rounded-lg">
                        <strong>{pkg.includedItemsCount.starters}</strong> Starters
                      </div>
                      <div className="p-2 bg-neutral-900/60 rounded-lg">
                        <strong>{pkg.includedItemsCount.mains}</strong> Main Courses
                      </div>
                      <div className="p-2 bg-neutral-900/60 rounded-lg">
                        <strong>{pkg.includedItemsCount.liveCounters}</strong> Live Counters
                      </div>
                      <div className="p-2 bg-neutral-900/60 rounded-lg">
                        <strong>{pkg.includedItemsCount.desserts}</strong> Desserts
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2 pt-4 border-t border-white/10">
                    {pkg.highlights.map((h, i) => (
                      <div key={i} className="flex items-center gap-2 text-xs text-gray-300">
                        <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        <span>{h}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-8">
                  <button
                    onClick={() => onOpenBookingWithPackage && onOpenBookingWithPackage(pkg)}
                    className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-600 text-black font-bold text-xs uppercase tracking-wider hover:brightness-110 shadow-lg transition-all"
                  >
                    Select {pkg.name}
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
