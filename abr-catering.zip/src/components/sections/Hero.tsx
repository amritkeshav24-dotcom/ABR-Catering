import React from 'react';
import { motion } from 'motion/react';
import { Crown, Sparkles, Calendar, Utensils, Star, ShieldCheck, Play, ArrowRight } from 'lucide-react';

interface HeroProps {
  onOpenBooking: () => void;
  onOpenChat: () => void;
}

export default function Hero({ onOpenBooking, onOpenChat }: HeroProps) {
  return (
    <section id="hero" className="relative min-h-[92vh] w-full flex items-center justify-center pt-28 pb-16 overflow-hidden bg-[#050505]">
      {/* Background Image / Gradient Overlay */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-r from-[#050505] via-[#050505]/85 to-transparent z-10" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-[#D4AF37]/15 via-transparent to-transparent z-10" />
        <img
          src="/src/assets/images/abr_hero_banner_1785492933080.jpg"
          alt="ABR Catering Royal Grand Feast Table"
          className="w-full h-full object-cover object-center opacity-40 mix-blend-luminosity filter brightness-90 scale-105"
          referrerPolicy="no-referrer"
        />
      </div>

      <div className="relative z-20 max-w-5xl mx-auto px-6 text-center md:text-left">
        {/* Established Eyebrow */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-black/60 border border-[#D4AF37]/30 text-[#D4AF37] font-serif italic text-sm md:text-base mb-6 shadow-[0_0_15px_rgba(212,175,55,0.15)]"
        >
          <Crown className="w-4 h-4 text-[#D4AF37]" />
          <span>Established 1998 • Royal Culinary Heritage</span>
        </motion.div>

        {/* Main Heading */}
        <motion.h1
          initial={{ opacity: 0, y: 25 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.2 }}
          className="text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-serif font-normal leading-[1.1] text-white mb-6"
        >
          Crafting <span className="italic font-serif">Royal</span><br/>
          Culinary <span className="text-[#D4AF37]">Experiences</span>
        </motion.h1>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-gray-400 text-base sm:text-xl leading-relaxed mb-10 max-w-2xl font-sans font-normal"
        >
          Where heritage meets modern gastronomy. We deliver bespoke catering for India's most prestigious weddings, corporate galas, and grand celebrations.
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex flex-col sm:flex-row items-center justify-center md:justify-start gap-4 sm:gap-6 mb-16"
        >
          <button
            onClick={onOpenBooking}
            className="w-full sm:w-auto px-10 py-4 bg-[#D4AF37] text-black font-bold uppercase tracking-widest text-xs hover:brightness-110 transition-all shadow-[0_0_25px_rgba(212,175,55,0.3)] flex items-center justify-center gap-3 group"
            id="hero-book-now-primary-btn"
          >
            <Calendar className="w-4 h-4 text-black" />
            <span>Book Your Event</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>

          <button
            onClick={onOpenChat}
            className="w-full sm:w-auto px-10 py-4 bg-white/5 border border-white/10 text-white font-bold uppercase tracking-widest text-xs backdrop-blur-sm hover:border-[#D4AF37]/50 hover:text-[#D4AF37] transition-all flex items-center justify-center gap-3"
            id="hero-ai-chat-btn"
          >
            <Sparkles className="w-4 h-4 text-[#D4AF37] animate-pulse" />
            <span>Ask AI Concierge</span>
          </button>
        </motion.div>

        {/* Highlights Bar */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 p-6 bg-black/40 border border-white/10 rounded-2xl max-w-4xl backdrop-blur-md"
        >
          <div className="flex flex-col items-center md:items-start p-2 border-r border-white/5 last:border-none">
            <span className="text-3xl font-serif text-[#D4AF37]">500+</span>
            <span className="text-[10px] text-gray-400 uppercase tracking-widest mt-1">Royal Events</span>
          </div>
          <div className="flex flex-col items-center md:items-start p-2 border-r border-white/5 last:border-none">
            <span className="text-3xl font-serif text-[#D4AF37]">50+</span>
            <span className="text-[10px] text-gray-400 uppercase tracking-widest mt-1">Master Artisans</span>
          </div>
          <div className="flex flex-col items-center md:items-start p-2 border-r border-white/5 last:border-none">
            <div className="flex items-center gap-1">
              <span className="text-3xl font-serif text-[#D4AF37]">4.9</span>
              <Star className="w-4 h-4 text-[#D4AF37] fill-[#D4AF37]" />
            </div>
            <span className="text-[10px] text-gray-400 uppercase tracking-widest mt-1">Client Rating</span>
          </div>
          <div className="flex flex-col items-center md:items-start p-2">
            <span className="text-3xl font-serif text-[#D4AF37]">100%</span>
            <span className="text-[10px] text-gray-400 uppercase tracking-widest mt-1">Bespoke Menus</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
