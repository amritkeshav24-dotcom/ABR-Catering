import React from 'react';
import { motion } from 'motion/react';
import { Crown, Sparkles, Utensils, Flame, Users, Globe, ChevronRight, Check } from 'lucide-react';

interface ServicesSectionProps {
  onOpenBooking: () => void;
}

export default function ServicesSection({ onOpenBooking }: ServicesSectionProps) {
  const services = [
    {
      id: 'wedding',
      title: 'Royal Wedding Feasts',
      icon: Crown,
      description: 'Opulent multi-cuisine wedding buffets featuring live brass chafing, 24K gold foil desserts, and custom regional counter setups.',
      highlights: ['Custom Menu Tasting Sessions', 'VIP Table Service Options', 'Live Molecular Chaat & Dessert Bars', 'Complete Decor Synchronization'],
      image: 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=800&q=80',
      badge: 'Most Popular'
    },
    {
      id: 'corporate',
      title: 'Corporate Galas & Summits',
      icon: Users,
      description: 'Precision-timed high-class catering for executive galas, product launches, and international delegate conferences.',
      highlights: ['Finger Food Pass-Arounds', 'Artisanal Coffee & Mocktail Bars', 'Strict Timed Service Discipline', 'FSSAI Certified Hygiene Standards'],
      image: 'https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=800&q=80'
    },
    {
      id: 'destination',
      title: 'Destination Catering',
      icon: Globe,
      description: 'Mobile kitchen infrastructure capable of delivering Michelin-grade feasts at heritage palaces, beachfronts, and remote luxury resorts.',
      highlights: ['Pan-India Operations', 'Self-Contained Mobile Master Kitchens', 'Local Regional Specialty Integration', 'Zero-Delay Logistics'],
      image: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80',
      badge: 'Signature'
    },
    {
      id: 'live-counters',
      title: 'Live Gastronomy Counters',
      icon: Flame,
      description: 'Engaging live chef stations including Neapolitan wood-fired pizzas, nitrogen flash-frozen gelato, and authentic clay tandoors.',
      highlights: ['Liquid Nitrogen Desserts', 'Hand-Stretching Pizza Chefs', 'Live Charcoal Kebab Grills', 'Interactive Sushi & Wok Counters'],
      image: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=800&q=80'
    }
  ];

  return (
    <section id="services" className="py-24 bg-[#050505] relative overflow-hidden border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-[#D4AF37]/30 text-[#D4AF37] text-xs font-semibold uppercase tracking-widest mb-4">
            <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>Exquisite Catering Solutions</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-serif text-white mb-6">
            Services Tailored for <span className="text-[#D4AF37] italic">Royal Celebrations</span>
          </h2>
          <p className="text-gray-400 text-base leading-relaxed">
            Every occasion demands a distinct culinary signature. ABR Catering combines age-old heritage recipes with modern culinary artistry.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="group relative rounded-2xl bg-neutral-900/60 border border-white/10 hover:border-[#D4AF37]/50 transition-all duration-300 flex flex-col justify-between overflow-hidden"
              >
                <div>
                  <div className="relative h-56 w-full overflow-hidden">
                    <img
                      src={service.image}
                      alt={service.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 filter brightness-90"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-[#050505]/40 to-transparent" />
                    
                    {service.badge && (
                      <span className="absolute top-4 right-4 px-3 py-1 bg-[#D4AF37] text-black font-bold text-[10px] uppercase tracking-widest shadow-lg">
                        {service.badge}
                      </span>
                    )}

                    <div className="absolute bottom-4 left-6 flex items-center gap-3">
                      <div className="w-10 h-10 border border-[#D4AF37]/40 bg-black/60 backdrop-blur-md flex items-center justify-center text-[#D4AF37]">
                        <Icon className="w-5 h-5" />
                      </div>
                      <h3 className="text-2xl font-serif text-white group-hover:text-[#D4AF37] transition-colors">
                        {service.title}
                      </h3>
                    </div>
                  </div>

                  <div className="p-6 space-y-4">
                    <p className="text-sm text-gray-300 leading-relaxed font-light">
                      {service.description}
                    </p>

                    <div className="space-y-2 pt-2 border-t border-white/5">
                      {service.highlights.map((h, i) => (
                        <div key={i} className="flex items-center gap-2.5 text-xs text-gray-300">
                          <Check className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
                          <span>{h}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="p-6 pt-0">
                  <button
                    onClick={onOpenBooking}
                    className="w-full py-3 bg-white/5 border border-[#D4AF37]/30 text-[#D4AF37] hover:bg-[#D4AF37] hover:text-black font-bold text-xs uppercase tracking-widest transition-all flex items-center justify-center gap-2 group/btn"
                  >
                    <span>Inquire for {service.title}</span>
                    <ChevronRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
