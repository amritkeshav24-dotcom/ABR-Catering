import React, { useState } from 'react';
import { motion } from 'motion/react';
import { MapPin, Navigation, Compass, Truck, Clock, CheckCircle2, ShieldAlert } from 'lucide-react';

export default function VenueMapSection() {
  const [selectedHub, setSelectedHub] = useState<string>('Delhi NCR');
  const [venueSearchInput, setVenueSearchInput] = useState<string>('');
  const [calculatedDistance, setCalculatedDistance] = useState<{
    covered: boolean;
    distanceKm: number;
    setupTimeHrs: number;
    notes: string;
  } | null>(null);

  const hubs = [
    { name: 'Delhi NCR', location: 'Lutyens Zone & MG Road Hub', lat: 28.6139, lng: 77.209, range: 'Servicing Delhi, Gurgaon, Noida & Faridabad' },
    { name: 'Mumbai', location: 'Bandra-Kurla Complex & Taj Expressway Hub', lat: 19.076, lng: 72.8777, range: 'Servicing Mumbai, Thane, Navi Mumbai & Lonavala' },
    { name: 'Jaipur', location: 'Heritage Palace Destination Hub', lat: 26.9124, lng: 75.7873, range: 'Servicing Jaipur Palaces, Udaipur & Jodhpur' },
    { name: 'Bengaluru', location: 'UB City & Sadashivanagar Hub', lat: 12.9716, lng: 77.5946, range: 'Servicing Bengaluru & Resort Hubs' },
  ];

  const checkCoverage = () => {
    if (!venueSearchInput) return;
    const lower = venueSearchInput.toLowerCase();
    
    // Simulate smart geographic calculation
    if (lower.includes('delhi') || lower.includes('gurgaon') || lower.includes('noida') || lower.includes('mumbai') || lower.includes('jaipur') || lower.includes('udaipur') || lower.includes('bengaluru') || lower.includes('goa')) {
      setCalculatedDistance({
        covered: true,
        distanceKm: Math.floor(15 + Math.random() * 45),
        setupTimeHrs: 3,
        notes: 'Full Mobile Kitchen unit and White-Glove service staff dispatch available!'
      });
    } else {
      setCalculatedDistance({
        covered: true,
        distanceKm: Math.floor(120 + Math.random() * 300),
        setupTimeHrs: 6,
        notes: 'Destination Event coverage active. Requires mobile generator and kitchen setup truck.'
      });
    }
  };

  return (
    <section id="venue-locator" className="py-24 bg-black relative border-t border-amber-500/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold uppercase tracking-wider mb-4">
            <Compass className="w-3.5 h-3.5" />
            <span>Google Maps Integration & Venue Coverage</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-white mb-6">
            Pan-India <span className="gold-gradient-text">Venue Reach</span>
          </h2>
          <p className="text-gray-400 text-base leading-relaxed">
            From luxury ballrooms to royal heritage palaces and remote destination lawns, our mobile catering fleet delivers seamless perfection.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
          {/* Venue Search & Logistics Panel */}
          <div className="lg:col-span-1 glass-card p-6 rounded-2xl space-y-6 border border-amber-500/30">
            <h3 className="font-serif font-bold text-xl text-white flex items-center gap-2">
              <Navigation className="w-5 h-5 text-amber-400" />
              Check Venue Logistics
            </h3>

            <div className="space-y-4">
              <label className="text-xs font-semibold text-gray-300 block">
                Enter Event Venue Name or Address:
              </label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="e.g. Taj Mahal Hotel, Oberoi Gurgaon, Leela Palace Jaipur..."
                  value={venueSearchInput}
                  onChange={(e) => setVenueSearchInput(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-neutral-900 border border-amber-500/20 text-white placeholder-gray-500 text-xs focus:outline-none focus:border-amber-400"
                />
              </div>

              <button
                onClick={checkCoverage}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-600 text-black font-bold text-xs uppercase tracking-wider shadow-md hover:brightness-110 transition-all"
              >
                Verify Catering Reach
              </button>

              {calculatedDistance && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-4 rounded-xl bg-neutral-900 border border-amber-500/30 space-y-3"
                >
                  <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Coverage Confirmed for Your Venue</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-[11px] text-gray-300">
                    <div className="flex items-center gap-1.5 p-2 bg-black/40 rounded-lg">
                      <Truck className="w-3.5 h-3.5 text-amber-400" />
                      <span>Distance: {calculatedDistance.distanceKm} km</span>
                    </div>
                    <div className="flex items-center gap-1.5 p-2 bg-black/40 rounded-lg">
                      <Clock className="w-3.5 h-3.5 text-amber-400" />
                      <span>Setup Lead: {calculatedDistance.setupTimeHrs} hrs</span>
                    </div>
                  </div>
                  <p className="text-[11px] text-gray-400 leading-relaxed italic">
                    {calculatedDistance.notes}
                  </p>
                </motion.div>
              )}
            </div>

            {/* Regional Hub Selector */}
            <div className="pt-4 border-t border-white/10 space-y-3">
              <span className="text-xs font-bold text-amber-400 uppercase tracking-wider block">
                Select Base Hub:
              </span>
              <div className="space-y-2">
                {hubs.map((hub) => (
                  <button
                    key={hub.name}
                    onClick={() => setSelectedHub(hub.name)}
                    className={`w-full p-3 rounded-xl text-left text-xs transition-all flex items-start gap-3 ${
                      selectedHub === hub.name
                        ? 'bg-amber-500/20 border border-amber-400 text-amber-200'
                        : 'bg-neutral-900 text-gray-400 border border-transparent hover:text-white'
                    }`}
                  >
                    <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="block text-white">{hub.name} Hub</strong>
                      <span className="text-[10px] text-gray-400">{hub.range}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Map Display Container */}
          <div className="lg:col-span-2 glass-card rounded-2xl overflow-hidden border border-amber-500/30 h-[460px] relative">
            {/* Embedded Google Map Styled Preview */}
            <iframe
              title="ABR Catering Base Maps"
              width="100%"
              height="100%"
              style={{ border: 0, filter: 'contrast(1.1) brightness(0.85) invert(0.9) hue-rotate(180deg)' }}
              loading="lazy"
              allowFullScreen
              src={`https://maps.google.com/maps?q=${encodeURIComponent(
                selectedHub === 'Delhi NCR' ? 'New Delhi, India' : selectedHub === 'Mumbai' ? 'Mumbai, India' : selectedHub === 'Jaipur' ? 'Jaipur, Rajasthan' : 'Bengaluru, India'
              )}&t=&z=11&ie=UTF8&iwloc=&output=embed`}
            />

            {/* Floating Royal Hub Badge Overlay */}
            <div className="absolute bottom-6 left-6 right-6 p-4 rounded-xl bg-neutral-950/90 backdrop-blur-md border border-amber-500/40 text-xs text-amber-200 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-2xl">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-emerald-400 animate-ping shrink-0" />
                <div>
                  <span className="font-bold text-white block">Active Hub: {selectedHub} Base</span>
                  <span className="text-[10px] text-gray-400">Mobile Kitchen Fleet & Cold-Chain Storage Ready</span>
                </div>
              </div>
              <a
                href={`https://maps.google.com/?q=${encodeURIComponent(selectedHub)}`}
                target="_blank"
                rel="noreferrer"
                className="px-4 py-2 rounded-lg bg-amber-500 text-black font-bold text-[11px] uppercase tracking-wider shrink-0 hover:brightness-110"
              >
                Open Google Maps
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
