import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GalleryItem } from '../../types';
import { Film, Image as ImageIcon, Heart, Play, Volume2, VolumeX, X, ChevronLeft, ChevronRight, Sparkles } from 'lucide-react';

interface GalleryReelsSectionProps {
  galleryItems: GalleryItem[];
}

export default function GalleryReelsSection({ galleryItems }: GalleryReelsSectionProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activeReelIndex, setActiveReelIndex] = useState<number | null>(null);
  const [isMuted, setIsMuted] = useState<boolean>(true);
  const [likedMap, setLikedMap] = useState<Record<string, boolean>>({});

  const categories = ['All', 'Weddings', 'Plating Art', 'Live Cooking', 'Reels'];

  const filteredItems = galleryItems.filter((item) => {
    if (selectedCategory === 'All') return true;
    if (selectedCategory === 'Reels') return item.mediaType === 'VIDEO';
    return item.category === selectedCategory;
  });

  const reelsList = galleryItems.filter((item) => item.mediaType === 'VIDEO');

  const toggleLike = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setLikedMap((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <section id="gallery" className="py-24 bg-neutral-950 relative overflow-hidden border-t border-amber-500/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold uppercase tracking-wider mb-4">
            <Film className="w-3.5 h-3.5" />
            <span>Visual Showcase & Live Reels</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-white mb-6">
            Witness The <span className="gold-gradient-text">Royal Grandeur</span>
          </h2>
          <p className="text-gray-400 text-base leading-relaxed">
            Step behind the scenes of our royal weddings, live nitrogen kitchens, and Michelin-grade plating arts.
          </p>

          {/* Category Filter Chips */}
          <div className="flex items-center justify-center gap-2 overflow-x-auto pt-8 pb-2">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-5 py-2 rounded-full text-xs font-bold tracking-wider transition-all whitespace-nowrap ${
                  selectedCategory === cat
                    ? 'bg-amber-500 text-black shadow-lg'
                    : 'bg-neutral-900 text-gray-400 hover:text-white border border-amber-500/20'
                }`}
              >
                {cat === 'Reels' ? '🎥 Video Reels' : cat}
              </button>
            ))}
          </div>
        </div>

        {/* Gallery & Reels Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredItems.map((item, idx) => {
            const isLiked = likedMap[item.id];
            const currentLikes = item.likesCount + (isLiked ? 1 : 0);

            return (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: idx * 0.05 }}
                onClick={() => {
                  if (item.mediaType === 'VIDEO') {
                    const rIdx = reelsList.findIndex((r) => r.id === item.id);
                    if (rIdx !== -1) setActiveReelIndex(rIdx);
                  }
                }}
                className="group relative rounded-2xl glass-card overflow-hidden cursor-pointer hover:border-amber-400/60 transition-all duration-300 aspect-[3/4]"
              >
                <img
                  src={item.thumbnailUrl || item.mediaUrl}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />

                {/* Media Type Badge */}
                <div className="absolute top-3 left-3 flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/60 backdrop-blur-md text-amber-300 border border-amber-500/30 text-[10px] font-bold uppercase">
                  {item.mediaType === 'VIDEO' ? (
                    <>
                      <Play className="w-3 h-3 text-amber-400 fill-amber-400" />
                      <span>Reel ({item.duration || '0:30'})</span>
                    </>
                  ) : (
                    <>
                      <ImageIcon className="w-3 h-3 text-amber-400" />
                      <span>Photo</span>
                    </>
                  )}
                </div>

                {/* Likes button */}
                <button
                  onClick={(e) => toggleLike(item.id, e)}
                  className="absolute top-3 right-3 p-2 rounded-full bg-black/60 backdrop-blur-md text-white hover:text-red-500 transition-colors"
                >
                  <Heart className={`w-4 h-4 ${isLiked ? 'text-red-500 fill-red-500' : ''}`} />
                </button>

                {/* Bottom info overlay */}
                <div className="absolute bottom-0 left-0 right-0 p-5 space-y-1">
                  <span className="text-[10px] font-semibold uppercase tracking-widest text-amber-400">
                    {item.category}
                  </span>
                  <h4 className="font-serif font-bold text-base text-white group-hover:text-amber-300 transition-colors">
                    {item.title}
                  </h4>
                  {item.caption && (
                    <p className="text-xs text-gray-300 line-clamp-2 font-light">
                      {item.caption}
                    </p>
                  )}
                  <div className="flex items-center gap-2 pt-2 text-[10px] text-gray-400">
                    <Heart className="w-3 h-3 text-red-400 fill-red-400" />
                    <span>{currentLikes} Likes</span>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Video Reel Modal Player */}
      <AnimatePresence>
        {activeReelIndex !== null && reelsList[activeReelIndex] && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/90 backdrop-blur-xl flex items-center justify-center p-4"
          >
            <div className="relative w-full max-w-sm h-[80vh] rounded-3xl overflow-hidden glass-card border border-amber-500/40 shadow-2xl flex flex-col justify-between">
              {/* Top controls */}
              <div className="absolute top-4 left-4 right-4 z-20 flex justify-between items-center">
                <div className="flex items-center gap-2 text-amber-300 text-xs font-bold">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span>ABR Royal Reels</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsMuted(!isMuted)}
                    className="p-2 rounded-full bg-black/60 text-white backdrop-blur-md hover:bg-neutral-800"
                  >
                    {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={() => setActiveReelIndex(null)}
                    className="p-2 rounded-full bg-black/60 text-white backdrop-blur-md hover:bg-neutral-800"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Video Player */}
              <div className="relative h-full w-full bg-black">
                <video
                  src={reelsList[activeReelIndex].mediaUrl}
                  autoPlay
                  loop
                  muted={isMuted}
                  playsInline
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-90" />
              </div>

              {/* Reel Info */}
              <div className="absolute bottom-6 left-4 right-4 z-20 space-y-2">
                <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold uppercase border border-amber-500/40">
                  {reelsList[activeReelIndex].category}
                </span>
                <h3 className="font-serif font-bold text-lg text-white">
                  {reelsList[activeReelIndex].title}
                </h3>
                <p className="text-xs text-gray-300 font-light leading-relaxed">
                  {reelsList[activeReelIndex].caption}
                </p>

                {/* Reel Nav Controls */}
                <div className="flex items-center justify-between pt-4 border-t border-white/10">
                  <button
                    disabled={activeReelIndex === 0}
                    onClick={() => setActiveReelIndex((prev) => (prev !== null && prev > 0 ? prev - 1 : prev))}
                    className="flex items-center gap-1 text-xs text-amber-300 disabled:opacity-30 hover:text-white"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span>Prev</span>
                  </button>
                  <span className="text-[10px] text-gray-400">
                    {activeReelIndex + 1} / {reelsList.length}
                  </span>
                  <button
                    disabled={activeReelIndex === reelsList.length - 1}
                    onClick={() => setActiveReelIndex((prev) => (prev !== null && prev < reelsList.length - 1 ? prev + 1 : prev))}
                    className="flex items-center gap-1 text-xs text-amber-300 disabled:opacity-30 hover:text-white"
                  >
                    <span>Next</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
