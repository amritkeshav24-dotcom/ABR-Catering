import React, { useState } from 'react';
import { CateringPackage, Booking } from '../../types';
import { X, Calendar, Users, MapPin, CheckCircle, CreditCard, ShieldCheck, ArrowRight, MessageCircle, Crown, Sparkles } from 'lucide-react';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedPackage?: CateringPackage | null;
  preselectedMenuIds?: string[];
  initialGuestCount?: number;
  onBookingComplete?: (booking: Booking) => void;
}

export default function BookingModal({
  isOpen,
  onClose,
  preselectedPackage,
  preselectedMenuIds,
  initialGuestCount = 150,
  onBookingComplete,
}: BookingModalProps) {
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  // Form Fields
  const [eventType, setEventType] = useState<'Wedding' | 'Corporate Gala' | 'Private Party' | 'Anniversary' | 'Destination Event' | 'Other'>('Wedding');
  const [eventDate, setEventDate] = useState<string>('2026-09-15');
  const [guestCount, setGuestCount] = useState<number>(initialGuestCount);
  const [venueLocation, setVenueLocation] = useState<string>('');
  
  const [customerName, setCustomerName] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [specialInstructions, setSpecialInstructions] = useState<string>('');

  const [perPlateRate, setPerPlateRate] = useState<number>(
    preselectedPackage ? preselectedPackage.pricePerPlate : 1250
  );

  const [createdBooking, setCreatedBooking] = useState<Booking | null>(null);
  const [isProcessingPayment, setIsProcessingPayment] = useState<boolean>(false);

  if (!isOpen) return null;

  const totalEstimate = perPlateRate * guestCount;
  const depositAmount = Math.max(5000, Math.round(totalEstimate * 0.1));

  const handleInitiatePayment = async () => {
    setIsProcessingPayment(true);
    try {
      // 1. Create order on server
      const res = await fetch('/api/bookings/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerName,
          email,
          phone,
          eventType,
          eventDate,
          guestCount,
          venueLocation,
          totalEstimate,
          depositAmount,
          specialInstructions
        })
      });

      const orderData = await res.json();

      // Simulate 1.5s Razorpay payment verification
      setTimeout(async () => {
        const verifyRes = await fetch('/api/bookings/verify', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            bookingId: orderData.booking.id,
            razorpayOrderId: orderData.razorpayOrderId,
            razorpayPaymentId: `pay_RZP_${Math.random().toString(36).substring(2, 10).toUpperCase()}`
          })
        });

        const verifyData = await verifyRes.json();
        setCreatedBooking(verifyData.booking);
        setIsProcessingPayment(false);
        setStep(4);
        if (onBookingComplete) onBookingComplete(verifyData.booking);
      }, 1500);

    } catch (err) {
      console.error(err);
      setIsProcessingPayment(false);
    }
  };

  const getWhatsAppReceiptLink = () => {
    if (!createdBooking) return '#';
    const text = `*ABR CATERING BOOKING RECEIPT*\nBooking ID: ${createdBooking.id}\nName: ${createdBooking.customerName}\nEvent: ${createdBooking.eventType}\nDate: ${createdBooking.eventDate}\nGuests: ${createdBooking.guestCount}\nVenue: ${createdBooking.venueLocation}\nDeposit Paid: ₹${createdBooking.depositAmount.toLocaleString('en-IN')}\nStatus: ${createdBooking.status}`;
    return `https://wa.me/919876543210?text=${encodeURIComponent(text)}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xl flex items-center justify-center p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl rounded-3xl glass-card border border-amber-500/40 p-6 md:p-8 space-y-6 shadow-2xl my-8">
        {/* Header */}
        <div className="flex justify-between items-center border-b border-amber-500/20 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-yellow-400 to-amber-600 flex items-center justify-center text-black font-bold">
              <Crown className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif font-bold text-xl text-white">Royal Event Reservation</h3>
              <p className="text-xs text-amber-300">Guaranteed Date Booking with Razorpay Payment Security</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-gray-400 hover:text-white rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Progress Bar */}
        {step < 4 && (
          <div className="grid grid-cols-3 gap-2">
            <div className={`h-1.5 rounded-full ${step >= 1 ? 'bg-amber-400' : 'bg-neutral-800'}`} />
            <div className={`h-1.5 rounded-full ${step >= 2 ? 'bg-amber-400' : 'bg-neutral-800'}`} />
            <div className={`h-1.5 rounded-full ${step >= 3 ? 'bg-amber-400' : 'bg-neutral-800'}`} />
          </div>
        )}

        {/* STEP 1: Event Details */}
        {step === 1 && (
          <div className="space-y-6">
            <h4 className="font-serif font-bold text-lg text-amber-300">Step 1: Event Specification</h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-semibold text-gray-300 block mb-1">Occasion Type:</label>
                <select
                  value={eventType}
                  onChange={(e: any) => setEventType(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-neutral-900 border border-amber-500/30 text-white text-xs"
                >
                  <option value="Wedding">Royal Wedding & Reception</option>
                  <option value="Corporate Gala">Corporate Summit & Gala</option>
                  <option value="Anniversary">Anniversary Celebration</option>
                  <option value="Private Party">VIP Villa Private Dinner</option>
                  <option value="Destination Event">Destination Palace Feast</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-semibold text-gray-300 block mb-1">Event Date:</label>
                <input
                  type="date"
                  value={eventDate}
                  onChange={(e) => setEventDate(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-neutral-900 border border-amber-500/30 text-white text-xs"
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs font-semibold text-gray-300">
                <span>Expected Guests Count:</span>
                <span className="text-amber-300 font-bold text-sm">{guestCount} Guests</span>
              </div>
              <input
                type="range"
                min="50"
                max="1000"
                step="25"
                value={guestCount}
                onChange={(e) => setGuestCount(Number(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-gray-300 block mb-1">Venue Location & City:</label>
              <input
                type="text"
                placeholder="e.g. Oberoi Ballroom, New Delhi or Private Farmhouse Gurgaon..."
                value={venueLocation}
                onChange={(e) => setVenueLocation(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-neutral-900 border border-amber-500/30 text-white text-xs"
              />
            </div>

            <button
              onClick={() => setStep(2)}
              disabled={!venueLocation}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-600 text-black font-bold text-xs uppercase tracking-wider disabled:opacity-40"
            >
              Continue to Package & Pricing
            </button>
          </div>
        )}

        {/* STEP 2: Pricing & Package Review */}
        {step === 2 && (
          <div className="space-y-6">
            <h4 className="font-serif font-bold text-lg text-amber-300">Step 2: Package & Estimate Summary</h4>

            <div className="p-4 rounded-xl bg-neutral-900 border border-amber-500/30 space-y-3">
              <div className="flex justify-between text-xs text-gray-300">
                <span>Selected Event:</span>
                <strong className="text-white">{eventType} ({guestCount} Guests)</strong>
              </div>
              <div className="flex justify-between text-xs text-gray-300">
                <span>Date & Venue:</span>
                <strong className="text-white">{eventDate} @ {venueLocation}</strong>
              </div>
              <div className="flex justify-between text-xs text-gray-300">
                <span>Per Plate Rate:</span>
                <strong className="text-amber-300">₹{perPlateRate} / plate</strong>
              </div>
              <div className="pt-2 border-t border-white/10 flex justify-between items-center">
                <span className="text-sm font-bold text-white">Estimated Full Catering Total:</span>
                <span className="font-serif font-bold text-xl text-amber-400">₹{totalEstimate.toLocaleString('en-IN')}</span>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 space-y-2">
              <div className="flex items-center gap-2 text-amber-300 font-bold text-xs">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                <span>Date Protection Deposit: ₹{depositAmount.toLocaleString('en-IN')} (10%)</span>
              </div>
              <p className="text-[11px] text-gray-400 leading-relaxed">
                Paying a 10% token deposit reserves our master chef team and mobile setup equipment for your date. Remaining balance payable on event date.
              </p>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setStep(1)}
                className="w-1/3 py-3 rounded-xl bg-neutral-900 text-gray-400 text-xs font-bold"
              >
                Back
              </button>
              <button
                onClick={() => setStep(3)}
                className="w-2/3 py-3.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-600 text-black font-bold text-xs uppercase tracking-wider"
              >
                Proceed to Host Contact Info
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: Contact Info & Razorpay Checkout Trigger */}
        {step === 3 && (
          <div className="space-y-6">
            <h4 className="font-serif font-bold text-lg text-amber-300">Step 3: Host Contact Details</h4>

            <div className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-gray-300 block mb-1">Host / Client Name:</label>
                <input
                  type="text"
                  placeholder="e.g. Vikramaditya Singh"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-neutral-900 border border-amber-500/30 text-white text-xs"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-gray-300 block mb-1">Phone (WhatsApp enabled):</label>
                  <input
                    type="tel"
                    placeholder="+91 98765 43210"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-neutral-900 border border-amber-500/30 text-white text-xs"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-gray-300 block mb-1">Email Address:</label>
                  <input
                    type="email"
                    placeholder="host@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-neutral-900 border border-amber-500/30 text-white text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-gray-300 block mb-1">Special Dietary / Decor Instructions:</label>
                <textarea
                  rows={2}
                  placeholder="e.g. Low spice options, Jain live counter needed..."
                  value={specialInstructions}
                  onChange={(e) => setSpecialInstructions(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-neutral-900 border border-amber-500/30 text-white text-xs"
                />
              </div>
            </div>

            <div className="pt-2 flex gap-3">
              <button
                onClick={() => setStep(2)}
                className="w-1/3 py-3 rounded-xl bg-neutral-900 text-gray-400 text-xs font-bold"
              >
                Back
              </button>
              <button
                onClick={handleInitiatePayment}
                disabled={!customerName || !phone || isProcessingPayment}
                className="w-2/3 py-3.5 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-600 text-black font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg disabled:opacity-50"
              >
                {isProcessingPayment ? (
                  <span>Processing Razorpay Checkout...</span>
                ) : (
                  <>
                    <CreditCard className="w-4 h-4" />
                    <span>Pay ₹{depositAmount.toLocaleString('en-IN')} Token Deposit</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* STEP 4: Success Receipt & WhatsApp Link */}
        {step === 4 && createdBooking && (
          <div className="space-y-6 text-center py-4">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500 text-emerald-400 flex items-center justify-center mx-auto">
              <CheckCircle className="w-8 h-8" />
            </div>

            <div>
              <h3 className="font-serif font-bold text-2xl text-white">Event Reserved Successfully!</h3>
              <p className="text-xs text-amber-300 mt-1">
                Booking ID: <strong className="text-white font-mono">{createdBooking.id}</strong>
              </p>
            </div>

            <div className="p-4 rounded-xl bg-neutral-900 border border-amber-500/30 text-left text-xs space-y-2">
              <div className="flex justify-between text-gray-300">
                <span>Customer Name:</span>
                <span className="font-bold text-white">{createdBooking.customerName}</span>
              </div>
              <div className="flex justify-between text-gray-300">
                <span>Event Date & Guest Count:</span>
                <span className="font-bold text-white">{createdBooking.eventDate} ({createdBooking.guestCount} Guests)</span>
              </div>
              <div className="flex justify-between text-gray-300">
                <span>Deposit Payment Verified:</span>
                <span className="font-bold text-emerald-400">₹{createdBooking.depositAmount.toLocaleString('en-IN')} (Paid)</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <a
                href={getWhatsAppReceiptLink()}
                target="_blank"
                rel="noreferrer"
                className="flex-1 py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Send Receipt to WhatsApp</span>
              </a>

              <button
                onClick={onClose}
                className="py-3.5 px-6 rounded-xl bg-neutral-900 border border-amber-500/30 text-amber-300 font-bold text-xs"
              >
                Done
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
