import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage } from '../../types';
import { Sparkles, X, Send, Bot, User, MessageCircle, Crown, ArrowRight, CornerDownLeft } from 'lucide-react';

interface AIChatbotModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenBooking: () => void;
}

export default function AIChatbotModal({ isOpen, onClose, onOpenBooking }: AIChatbotModalProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'm_welcome',
      sender: 'assistant',
      text: 'Namaste! I am your ABR Royal Catering Concierge. How may I assist you today? I can recommend custom menus, calculate guest estimates, or reserve event dates in English, Hindi, or Hinglish!',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);

  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  if (!isOpen) return null;

  const quickPrompts = [
    'Recommend a menu for 200 wedding guests',
    '200 लोगों के लिए कैटरिंग का पैकेज रेट क्या है?',
    'Show live molecular nitrogen dessert counters',
    'How do I pay deposit to lock my event date?'
  ];

  const handleSend = async (textToSend?: string) => {
    const query = textToSend || input;
    if (!query.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: `usr_${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInput('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [...messages, userMsg].map((m) => ({
            role: m.sender === 'user' ? 'user' : 'model',
            content: m.text
          })),
          userLanguage: 'Hinglish'
        })
      });

      const data = await response.json();

      const botMsg: ChatMessage = {
        id: `bot_${Date.now()}`,
        sender: 'assistant',
        text: data.content || data.fallback || 'Namaste! Please feel free to book directly or chat with us on WhatsApp!',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages((prev) => [...prev, botMsg]);
    } catch (err) {
      console.error(err);
      setMessages((prev) => [
        ...prev,
        {
          id: `bot_err_${Date.now()}`,
          sender: 'assistant',
          text: 'Namaste! For immediate response, you can also connect directly with our Event Manager on WhatsApp (+91 98765 43210).',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const getWhatsAppChatTransferUrl = () => {
    const lastUserQuery = messages.filter((m) => m.sender === 'user').pop()?.text || 'I would like to inquire about royal catering for my event.';
    return `https://wa.me/919876543210?text=${encodeURIComponent(`Hello ABR Catering Concierge! I was chatting with AI Assistant about: "${lastUserQuery}". Please assist me with my event booking.`)}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="relative w-full max-w-lg h-[650px] rounded-3xl glass-card border border-amber-500/40 flex flex-col justify-between overflow-hidden shadow-2xl">
        {/* Top Bar */}
        <div className="p-4 bg-neutral-950/90 border-b border-amber-500/20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 via-amber-500 to-yellow-600 flex items-center justify-center text-black font-bold shadow-md">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif font-bold text-base text-white flex items-center gap-2">
                ABR AI Concierge
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              </h3>
              <p className="text-[10px] text-amber-200/80">Gemini 3.6 Flash • English, Hindi & Hinglish</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-gray-400 hover:text-white rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Message Thread */}
        <div className="flex-1 p-4 overflow-y-auto space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex items-start gap-3 ${msg.sender === 'user' ? 'flex-row-reverse' : ''}`}
            >
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-xs shrink-0 ${
                  msg.sender === 'user'
                    ? 'bg-amber-500 text-black font-bold'
                    : 'bg-neutral-800 border border-amber-500/30 text-amber-300'
                }`}
              >
                {msg.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              <div
                className={`max-w-[80%] p-3.5 rounded-2xl text-xs leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-black font-medium'
                    : 'bg-neutral-900 border border-amber-500/20 text-gray-200'
                }`}
              >
                <p className="whitespace-pre-wrap">{msg.text}</p>
                <span className="text-[9px] opacity-60 block text-right mt-1 font-mono">
                  {msg.timestamp}
                </span>
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center gap-2 text-xs text-amber-400 italic p-2">
              <Sparkles className="w-4 h-4 animate-spin text-amber-400" />
              <span>AI Concierge is crafting royal response...</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Chips */}
        <div className="px-4 py-2 bg-neutral-950/60 border-t border-white/5 flex gap-2 overflow-x-auto scrollbar-none">
          {quickPrompts.map((qp, i) => (
            <button
              key={i}
              onClick={() => handleSend(qp)}
              className="px-3 py-1.5 rounded-full bg-neutral-900 border border-amber-500/20 text-[10px] text-amber-200 hover:bg-amber-500/20 whitespace-nowrap"
            >
              {qp}
            </button>
          ))}
        </div>

        {/* Bottom Actions & Input */}
        <div className="p-4 bg-neutral-950 border-t border-amber-500/20 space-y-3">
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Ask anything in English or Hindi (e.g. '200 guests menu')..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              className="flex-1 px-4 py-2.5 rounded-xl bg-neutral-900 border border-amber-500/30 text-white text-xs placeholder-gray-500 focus:outline-none focus:border-amber-400"
            />
            <button
              onClick={() => handleSend()}
              disabled={isLoading || !input.trim()}
              className="px-4 py-2.5 rounded-xl bg-amber-500 text-black font-bold hover:brightness-110 disabled:opacity-40"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center justify-between text-[11px] pt-1">
            <button
              onClick={() => {
                onClose();
                onOpenBooking();
              }}
              className="text-amber-300 font-semibold hover:underline flex items-center gap-1"
            >
              <span>Ready? Reserve Date Now</span>
              <ArrowRight className="w-3 h-3" />
            </button>

            <a
              href={getWhatsAppChatTransferUrl()}
              target="_blank"
              rel="noreferrer"
              className="text-emerald-400 font-semibold flex items-center gap-1 hover:underline"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>Continue on WhatsApp</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
