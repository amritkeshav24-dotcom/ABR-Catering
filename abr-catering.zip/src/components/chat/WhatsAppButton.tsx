import React from 'react';
import { MessageCircle } from 'lucide-react';

export default function WhatsAppButton() {
  const whatsappUrl = "https://wa.me/919876543210?text=Hello%20ABR%20Catering!%20I%20would%20like%20to%20inquire%20about%20event%20catering%20services.";

  return (
    <a
      href={whatsappUrl}
      target="_blank"
      rel="noreferrer"
      id="floating-whatsapp-btn"
      className="fixed bottom-6 right-6 z-40 w-14 h-14 rounded-full bg-emerald-500 hover:bg-emerald-400 text-white flex items-center justify-center shadow-[0_0_25px_rgba(16,185,129,0.5)] transition-all hover:scale-110 group"
      title="Chat on WhatsApp (+91 98765 43210)"
    >
      <MessageCircle className="w-7 h-7 stroke-[2.2]" />
      <span className="absolute right-16 px-3 py-1.5 rounded-xl bg-neutral-900 border border-emerald-500/30 text-emerald-300 text-xs font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity shadow-lg">
        Chat on WhatsApp
      </span>
    </a>
  );
}
