import React from 'react';
import { Crown, MapPin, Phone, Mail, Instagram, Facebook, Youtube, Shield, Award, Heart } from 'lucide-react';

interface FooterProps {
  onOpenBooking: () => void;
  onOpenAdmin: () => void;
}

export default function Footer({ onOpenBooking, onOpenAdmin }: FooterProps) {
  return (
    <footer id="main-footer" className="bg-[#050505] border-t border-white/5 text-gray-400 pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand Info */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 border-2 border-[#D4AF37] flex items-center justify-center font-serif text-xl font-bold text-[#D4AF37]">
                A
              </div>
              <span className="font-serif text-xl font-bold tracking-[0.15em] text-white uppercase">
                ABR <span className="text-[#D4AF37]">Catering</span>
              </span>
            </div>
            <p className="text-sm text-gray-400 leading-relaxed font-light">
              Crafting unforgettable royal culinary experiences for grand weddings, corporate galas, and VIP private celebrations across India.
            </p>
            <div className="flex items-center gap-4 pt-2">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 border border-[#D4AF37]/30 flex items-center justify-center text-[#D4AF37] hover:bg-[#D4AF37] hover:text-black transition-all"
                id="footer-instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 border border-[#D4AF37]/30 flex items-center justify-center text-[#D4AF37] hover:bg-[#D4AF37] hover:text-black transition-all"
                id="footer-facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 border border-[#D4AF37]/30 flex items-center justify-center text-[#D4AF37] hover:bg-[#D4AF37] hover:text-black transition-all"
                id="footer-youtube"
              >
                <Youtube className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="font-serif text-base font-bold text-[#D4AF37] uppercase tracking-widest border-b border-white/5 pb-2 inline-block">
              Quick Navigation
            </h4>
            <ul className="space-y-2.5 text-xs font-medium uppercase tracking-wider">
              <li>
                <a href="#hero" className="hover:text-[#D4AF37] transition-colors">Royal Heritage Feasts</a>
              </li>
              <li>
                <a href="#services" className="hover:text-[#D4AF37] transition-colors">Catering Services</a>
              </li>
              <li>
                <a href="#menu" className="hover:text-[#D4AF37] transition-colors">Interactive Menu & Price Calculator</a>
              </li>
              <li>
                <a href="#gallery" className="hover:text-[#D4AF37] transition-colors">Gallery & Video Reels</a>
              </li>
              <li>
                <a href="#venue-locator" className="hover:text-[#D4AF37] transition-colors">Google Maps Venue Locator</a>
              </li>
              <li>
                <a href="#reviews" className="hover:text-[#D4AF37] transition-colors">Verified Customer Reviews</a>
              </li>
            </ul>
          </div>

          {/* Contact Details */}
          <div className="space-y-4">
            <h4 className="font-serif text-base font-bold text-[#D4AF37] uppercase tracking-widest border-b border-white/5 pb-2 inline-block">
              Royal Concierge Contact
            </h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
                <span>ABR Royal Culinary Center, MG Road, New Delhi & Taj Expressway Hub, Mumbai</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-[#D4AF37] shrink-0" />
                <a href="tel:+919876543210" className="hover:text-[#D4AF37] font-semibold text-white">
                  +91 98765 43210
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-[#D4AF37] shrink-0" />
                <a href="mailto:events@abrcatering.com" className="hover:text-[#D4AF37]">
                  events@abrcatering.com
                </a>
              </li>
            </ul>
          </div>

          {/* Guarantees & Booking */}
          <div className="space-y-4">
            <h4 className="font-serif text-base font-bold text-[#D4AF37] uppercase tracking-widest border-b border-white/5 pb-2 inline-block">
              The ABR Promise
            </h4>
            <div className="space-y-3 text-xs text-gray-300">
              <div className="flex items-center gap-2 p-2.5 bg-neutral-900 border border-white/5">
                <Shield className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span>100% Food Safety & FSSAI Certified Master Kitchens</span>
              </div>
              <div className="flex items-center gap-2 p-2.5 bg-neutral-900 border border-white/5">
                <Award className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span>Award-winning Master Chefs from Awadh & Bengal</span>
              </div>
            </div>
            <button
              onClick={onOpenBooking}
              className="w-full mt-2 py-3 bg-[#D4AF37] text-black font-bold text-xs uppercase tracking-widest hover:brightness-110 transition-all shadow-[0_0_15px_rgba(212,175,55,0.2)]"
              id="footer-book-now-btn"
            >
              Reserve Event Date Online
            </button>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between text-xs text-gray-500 gap-4">
          <p>© 2026 ABR Catering Ltd. All rights reserved. Royal Culinary Experiences.</p>
          <div className="flex items-center gap-6">
            <button
              onClick={onOpenAdmin}
              className="hover:text-[#D4AF37] transition-colors cursor-pointer uppercase tracking-wider"
              id="footer-admin-login-link"
            >
              Admin Dashboard Login
            </button>
            <span>•</span>
            <span className="flex items-center gap-1 text-gray-400">
              Powered by <Heart className="w-3.5 h-3.5 text-red-500 fill-current inline" /> Gemini AI Engine
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
