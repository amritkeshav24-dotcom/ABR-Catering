import React, { useState, useEffect } from 'react';
import { Crown, Phone, Calendar, ShieldCheck, Menu as MenuIcon, X, Sparkles, MessageCircle } from 'lucide-react';

interface NavbarProps {
  onOpenBooking: () => void;
  onOpenAdmin: () => void;
  onOpenChat: () => void;
}

export default function Navbar({ onOpenBooking, onOpenAdmin, onOpenChat }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      id="main-navbar"
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled
          ? 'bg-neutral-950/90 backdrop-blur-md border-b border-yellow-500/20 py-3 shadow-2xl'
          : 'bg-gradient-to-b from-black/80 via-black/40 to-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <a
            href="#"
            className="flex items-center gap-3 group"
            id="brand-logo-link"
          >
            <div className="w-10 h-10 border-2 border-[#D4AF37] flex items-center justify-center font-serif text-xl font-bold text-[#D4AF37] shadow-[0_0_15px_rgba(212,175,55,0.25)] group-hover:bg-[#D4AF37] group-hover:text-black transition-all">
              A
            </div>
            <div className="flex flex-col">
              <span className="font-serif text-xl md:text-2xl font-bold tracking-[0.15em] text-white uppercase">
                ABR <span className="text-[#D4AF37]">Catering</span>
              </span>
              <span className="text-[9px] uppercase tracking-[0.25em] text-[#D4AF37]/80 font-sans">
                Royal Culinary Feasts
              </span>
            </div>
          </a>

          {/* Desktop Nav Links */}
          <nav className="hidden md:flex items-center gap-8 text-xs font-medium uppercase tracking-[0.2em]">
            <button
              onClick={() => scrollToSection('hero')}
              className="text-[#D4AF37] transition-colors"
              id="nav-home-btn"
            >
              Home
            </button>
            <button
              onClick={() => scrollToSection('services')}
              className="text-gray-300 hover:text-[#D4AF37] transition-colors"
              id="nav-services-btn"
            >
              Services
            </button>
            <button
              onClick={() => scrollToSection('menu')}
              className="text-gray-300 hover:text-[#D4AF37] transition-colors"
              id="nav-menu-btn"
            >
              Menu & Packages
            </button>
            <button
              onClick={() => scrollToSection('gallery')}
              className="text-gray-300 hover:text-[#D4AF37] transition-colors"
              id="nav-gallery-btn"
            >
              Gallery & Reels
            </button>
            <button
              onClick={() => scrollToSection('venue-locator')}
              className="text-gray-300 hover:text-[#D4AF37] transition-colors"
              id="nav-venue-btn"
            >
              Venue Locator
            </button>
            <button
              onClick={() => scrollToSection('reviews')}
              className="text-gray-300 hover:text-[#D4AF37] transition-colors"
              id="nav-reviews-btn"
            >
              Reviews
            </button>
          </nav>

          {/* Actions */}
          <div className="hidden lg:flex items-center gap-4">
            <button
              onClick={onOpenChat}
              className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-neutral-900 border border-[#D4AF37]/30 text-[#D4AF37] hover:bg-neutral-800 text-xs font-semibold uppercase tracking-wider transition-all hover:border-[#D4AF37]"
              id="nav-ai-assistant-btn"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#D4AF37] animate-pulse" />
              <span>AI Concierge</span>
            </button>

            <a
              href="tel:+919876543210"
              className="flex items-center gap-2 text-xs font-semibold text-gray-300 hover:text-[#D4AF37] transition-colors px-3 py-2"
              id="nav-phone-link"
            >
              <Phone className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>+91 98765 43210</span>
            </a>

            <button
              onClick={onOpenAdmin}
              className="px-3 py-2 text-xs text-gray-400 hover:text-[#D4AF37] border border-white/10 hover:border-[#D4AF37]/40 rounded-lg transition-colors uppercase tracking-wider"
              id="nav-admin-portal-btn"
            >
              Admin Portal
            </button>

            <button
              onClick={onOpenBooking}
              className="px-6 py-2.5 border border-[#D4AF37] text-[#D4AF37] hover:bg-[#D4AF37] hover:text-black font-bold text-xs uppercase tracking-[0.15em] transition-all shadow-[0_0_15px_rgba(212,175,55,0.2)] flex items-center gap-2"
              id="nav-book-now-btn"
            >
              <Calendar className="w-4 h-4" />
              <span>Book Event</span>
            </button>
          </div>

          {/* Mobile menu toggle */}
          <div className="flex items-center gap-3 md:hidden">
            <button
              onClick={onOpenBooking}
              className="px-3.5 py-1.5 rounded-full bg-amber-400 text-black font-bold text-xs"
              id="mobile-nav-book-btn"
            >
              Book
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-gray-300 hover:text-amber-400"
              id="mobile-menu-toggle-btn"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <MenuIcon className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div
          id="mobile-dropdown-menu"
          className="md:hidden bg-neutral-950/95 border-b border-amber-500/20 px-4 pt-4 pb-6 space-y-3 mt-3 backdrop-blur-xl"
        >
          <button
            onClick={() => scrollToSection('hero')}
            className="block w-full text-left py-2 text-gray-300 hover:text-amber-400 font-medium"
          >
            Home
          </button>
          <button
            onClick={() => scrollToSection('services')}
            className="block w-full text-left py-2 text-gray-300 hover:text-amber-400 font-medium"
          >
            Services
          </button>
          <button
            onClick={() => scrollToSection('menu')}
            className="block w-full text-left py-2 text-gray-300 hover:text-amber-400 font-medium"
          >
            Menu & Packages
          </button>
          <button
            onClick={() => scrollToSection('gallery')}
            className="block w-full text-left py-2 text-gray-300 hover:text-amber-400 font-medium"
          >
            Gallery & Reels
          </button>
          <button
            onClick={() => scrollToSection('venue-locator')}
            className="block w-full text-left py-2 text-gray-300 hover:text-amber-400 font-medium"
          >
            Venue Locator
          </button>
          <button
            onClick={() => scrollToSection('reviews')}
            className="block w-full text-left py-2 text-gray-300 hover:text-amber-400 font-medium"
          >
            Reviews
          </button>

          <div className="pt-4 border-t border-white/10 flex flex-col gap-3">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenChat();
              }}
              className="flex items-center justify-center gap-2 py-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 font-semibold text-sm"
            >
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>Ask AI Catering Concierge</span>
            </button>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenAdmin();
              }}
              className="py-2 text-xs text-gray-400 text-center hover:text-amber-400"
            >
              Admin Portal
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
