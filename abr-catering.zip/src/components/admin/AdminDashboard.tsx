import React, { useState, useEffect } from 'react';
import { Booking, MenuItem, GalleryItem, CustomerReview, AdminStats } from '../../types';
import {
  X,
  LayoutDashboard,
  Calendar,
  Utensils,
  Film,
  MessageSquare,
  TrendingUp,
  DollarSign,
  Users,
  CheckCircle,
  Clock,
  Plus,
  Trash2,
  Edit,
  Send,
  Lock,
  MessageCircle,
  Eye,
  ShieldAlert
} from 'lucide-react';

interface AdminDashboardProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AdminDashboard({ isOpen, onClose }: AdminDashboardProps) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [adminEmail, setAdminEmail] = useState('admin@abrcatering.com');
  const [adminPass, setAdminPass] = useState('Admin@ABR2026');
  const [activeTab, setActiveTab] = useState<'overview' | 'bookings' | 'menu' | 'gallery' | 'reviews'>('overview');

  // Admin Data State
  const [stats, setStats] = useState<AdminStats>({
    totalRevenue: 678500,
    activeBookingsCount: 5,
    pendingInquiriesCount: 2,
    totalMenuItems: 11,
    averageRating: 4.9
  });

  const [bookings, setBookings] = useState<Booking[]>([]);
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [galleryItems, setGalleryItems] = useState<GalleryItem[]>([]);
  const [reviews, setReviews] = useState<CustomerReview[]>([]);

  // Menu Form State
  const [newMenuName, setNewMenuName] = useState('');
  const [newMenuCategory, setNewMenuCategory] = useState<any>('Starters');
  const [newMenuPrice, setNewMenuPrice] = useState(300);
  const [newMenuDietary, setNewMenuDietary] = useState<any>('veg');
  const [newMenuImg, setNewMenuImg] = useState('');
  const [newMenuDesc, setNewMenuDesc] = useState('');

  // Gallery Form State
  const [newMediaTitle, setNewMediaTitle] = useState('');
  const [newMediaCat, setNewMediaCat] = useState<any>('Weddings');
  const [newMediaType, setNewMediaType] = useState<'IMAGE' | 'VIDEO'>('IMAGE');
  const [newMediaUrl, setNewMediaUrl] = useState('');

  useEffect(() => {
    if (isOpen && isAuthenticated) {
      fetchAdminData();
    }
  }, [isOpen, isAuthenticated]);

  const fetchAdminData = async () => {
    try {
      const [resStats, resBookings, resMenu, resGallery, resReviews] = await Promise.all([
        fetch('/api/stats').then(r => r.json()),
        fetch('/api/bookings').then(r => r.json()),
        fetch('/api/menu').then(r => r.json()),
        fetch('/api/gallery').then(r => r.json()),
        fetch('/api/reviews').then(r => r.json())
      ]);

      setStats(resStats);
      setBookings(resBookings);
      setMenuItems(resMenu.items || []);
      setGalleryItems(resGallery);
      setReviews(resReviews);
    } catch (err) {
      console.error(err);
    }
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminEmail === 'admin@abrcatering.com' && adminPass) {
      setIsAuthenticated(true);
    }
  };

  const updateBookingStatus = async (id: string, status: any) => {
    await fetch(`/api/bookings/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status })
    });
    setBookings(prev => prev.map(b => (b.id === id ? { ...b, status } : b)));
  };

  const handleAddMenuItem = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/menu', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: newMenuName,
        category: newMenuCategory,
        pricePerPlate: newMenuPrice,
        dietary: newMenuDietary,
        imageUrl: newMenuImg || 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80',
        description: newMenuDesc
      })
    });
    const newItem = await res.json();
    setMenuItems([newItem, ...menuItems]);
    setNewMenuName('');
    setNewMenuDesc('');
  };

  const handleDeleteMenuItem = async (id: string) => {
    await fetch(`/api/menu/${id}`, { method: 'DELETE' });
    setMenuItems(prev => prev.filter(i => i.id !== id));
  };

  const handleAddMedia = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/gallery', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: newMediaTitle,
        category: newMediaCat,
        mediaType: newMediaType,
        mediaUrl: newMediaUrl || 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=800&q=80',
        thumbnailUrl: newMediaUrl || 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=800&q=80'
      })
    });
    const newMedia = await res.json();
    setGalleryItems([newMedia, ...galleryItems]);
    setNewMediaTitle('');
    setNewMediaUrl('');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-xl flex items-center justify-center p-4 overflow-y-auto">
      <div className="relative w-full max-w-5xl h-[85vh] rounded-3xl glass-card border border-amber-500/40 flex flex-col justify-between overflow-hidden shadow-2xl my-auto">
        {/* Top Header */}
        <div className="p-4 bg-neutral-950 border-b border-amber-500/20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-400/40 text-amber-300 flex items-center justify-center">
              <LayoutDashboard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif font-bold text-lg text-white">ABR Royal Command Center</h3>
              <p className="text-[10px] text-gray-400">Enterprise Administration & Booking Operations</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-gray-400 hover:text-white rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Auth Screen */}
        {!isAuthenticated ? (
          <div className="flex-1 flex items-center justify-center p-6">
            <div className="w-full max-w-sm glass-card p-8 rounded-2xl border border-amber-500/30 space-y-6">
              <div className="text-center space-y-2">
                <div className="w-12 h-12 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto border border-amber-500/40">
                  <Lock className="w-6 h-6" />
                </div>
                <h4 className="font-serif font-bold text-xl text-white">Admin Authentication</h4>
                <p className="text-xs text-gray-400">Pre-filled credentials for instant admin access</p>
              </div>

              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label className="text-xs font-semibold text-gray-300 block mb-1">Email Address:</label>
                  <input
                    type="email"
                    value={adminEmail}
                    onChange={(e) => setAdminEmail(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-amber-500/20 text-white text-xs"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-gray-300 block mb-1">Password:</label>
                  <input
                    type="password"
                    value={adminPass}
                    onChange={(e) => setAdminPass(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-amber-500/20 text-white text-xs"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-600 text-black font-bold text-xs uppercase tracking-wider shadow-lg"
                >
                  Access Admin Dashboard
                </button>
              </form>
            </div>
          </div>
        ) : (
          /* Main Admin Layout */
          <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
            {/* Sidebar Tabs */}
            <div className="w-full md:w-56 bg-neutral-950/80 border-r border-amber-500/20 p-4 space-y-2">
              <button
                onClick={() => setActiveTab('overview')}
                className={`w-full p-3 rounded-xl text-xs font-bold flex items-center gap-2.5 transition-all ${
                  activeTab === 'overview'
                    ? 'bg-amber-500 text-black shadow-md'
                    : 'text-gray-400 hover:text-white hover:bg-neutral-900'
                }`}
              >
                <TrendingUp className="w-4 h-4" />
                <span>Overview Analytics</span>
              </button>

              <button
                onClick={() => setActiveTab('bookings')}
                className={`w-full p-3 rounded-xl text-xs font-bold flex items-center gap-2.5 transition-all ${
                  activeTab === 'bookings'
                    ? 'bg-amber-500 text-black shadow-md'
                    : 'text-gray-400 hover:text-white hover:bg-neutral-900'
                }`}
              >
                <Calendar className="w-4 h-4" />
                <span>Event Bookings ({bookings.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('menu')}
                className={`w-full p-3 rounded-xl text-xs font-bold flex items-center gap-2.5 transition-all ${
                  activeTab === 'menu'
                    ? 'bg-amber-500 text-black shadow-md'
                    : 'text-gray-400 hover:text-white hover:bg-neutral-900'
                }`}
              >
                <Utensils className="w-4 h-4" />
                <span>Menu Management</span>
              </button>

              <button
                onClick={() => setActiveTab('gallery')}
                className={`w-full p-3 rounded-xl text-xs font-bold flex items-center gap-2.5 transition-all ${
                  activeTab === 'gallery'
                    ? 'bg-amber-500 text-black shadow-md'
                    : 'text-gray-400 hover:text-white hover:bg-neutral-900'
                }`}
              >
                <Film className="w-4 h-4" />
                <span>Gallery & Reels</span>
              </button>
            </div>

            {/* Content View */}
            <div className="flex-1 p-6 overflow-y-auto space-y-6">
              {/* TAB 1: OVERVIEW */}
              {activeTab === 'overview' && (
                <div className="space-y-6">
                  {/* KPI Cards */}
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="p-4 rounded-xl bg-neutral-900 border border-amber-500/20 space-y-2">
                      <span className="text-[10px] text-gray-400 uppercase tracking-wider block">Total Sales</span>
                      <span className="font-serif font-bold text-2xl text-amber-400">
                        ₹{stats.totalRevenue.toLocaleString('en-IN')}
                      </span>
                    </div>

                    <div className="p-4 rounded-xl bg-neutral-900 border border-amber-500/20 space-y-2">
                      <span className="text-[10px] text-gray-400 uppercase tracking-wider block">Confirmed Events</span>
                      <span className="font-serif font-bold text-2xl text-emerald-400">
                        {stats.activeBookingsCount} Events
                      </span>
                    </div>

                    <div className="p-4 rounded-xl bg-neutral-900 border border-amber-500/20 space-y-2">
                      <span className="text-[10px] text-gray-400 uppercase tracking-wider block">Pending Inquiries</span>
                      <span className="font-serif font-bold text-2xl text-yellow-400">
                        {stats.pendingInquiriesCount} Pending
                      </span>
                    </div>

                    <div className="p-4 rounded-xl bg-neutral-900 border border-amber-500/20 space-y-2">
                      <span className="text-[10px] text-gray-400 uppercase tracking-wider block">Menu Items</span>
                      <span className="font-serif font-bold text-2xl text-amber-300">
                        {stats.totalMenuItems} Items
                      </span>
                    </div>
                  </div>

                  {/* Recent Bookings Activity */}
                  <div className="space-y-3">
                    <h4 className="font-serif font-bold text-base text-white">Recent Booking Requests</h4>
                    <div className="space-y-2">
                      {bookings.slice(0, 3).map((b) => (
                        <div key={b.id} className="p-4 rounded-xl bg-neutral-900/80 border border-amber-500/20 flex items-center justify-between text-xs">
                          <div>
                            <strong className="text-white block">{b.customerName}</strong>
                            <span className="text-gray-400">{b.eventType} • {b.eventDate} ({b.guestCount} Guests)</span>
                          </div>
                          <span className={`px-3 py-1 rounded-full font-bold text-[10px] ${
                            b.status === 'CONFIRMED' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-yellow-500/20 text-yellow-300'
                          }`}>
                            {b.status}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: BOOKINGS MANAGER */}
              {activeTab === 'bookings' && (
                <div className="space-y-4">
                  <h4 className="font-serif font-bold text-lg text-white">Manage All Event Reservations</h4>
                  <div className="space-y-3">
                    {bookings.map((b) => (
                      <div key={b.id} className="p-5 rounded-xl bg-neutral-900 border border-amber-500/20 space-y-3">
                        <div className="flex flex-col md:flex-row justify-between md:items-center gap-2">
                          <div>
                            <span className="font-mono text-[10px] text-amber-400 font-bold">{b.id}</span>
                            <h5 className="font-serif font-bold text-base text-white">{b.customerName}</h5>
                            <p className="text-xs text-gray-400">{b.eventType} • {b.eventDate} • {b.venueLocation}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <select
                              value={b.status}
                              onChange={(e) => updateBookingStatus(b.id, e.target.value)}
                              className="px-3 py-1.5 rounded-lg bg-black border border-amber-500/30 text-amber-300 text-xs font-bold"
                            >
                              <option value="PENDING">PENDING</option>
                              <option value="CONFIRMED">CONFIRMED</option>
                              <option value="COMPLETED">COMPLETED</option>
                              <option value="CANCELLED">CANCELLED</option>
                            </select>

                            <a
                              href={`https://wa.me/${b.phone.replace(/[^0-9]/g, '')}?text=Hello%20${encodeURIComponent(b.customerName)}!%20This%20is%20ABR%20Catering.%20Regarding%20your%20booking%20${b.id}...`}
                              target="_blank"
                              rel="noreferrer"
                              className="p-2 rounded-lg bg-emerald-600 text-white hover:bg-emerald-500"
                            >
                              <MessageCircle className="w-4 h-4" />
                            </a>
                          </div>
                        </div>

                        <div className="pt-2 border-t border-white/10 flex justify-between text-xs text-gray-400">
                          <span>Deposit Paid: ₹{b.depositAmount.toLocaleString('en-IN')}</span>
                          <span>Total Estimate: ₹{b.totalEstimate.toLocaleString('en-IN')}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 3: MENU CRUD */}
              {activeTab === 'menu' && (
                <div className="space-y-6">
                  {/* Create New Dish Form */}
                  <form onSubmit={handleAddMenuItem} className="p-4 rounded-xl bg-neutral-900 border border-amber-500/30 space-y-3">
                    <h5 className="font-serif font-bold text-sm text-amber-300">Add New Royal Delicacy</h5>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                      <input
                        type="text"
                        placeholder="Dish Name"
                        required
                        value={newMenuName}
                        onChange={(e) => setNewMenuName(e.target.value)}
                        className="p-2 rounded-lg bg-black border border-amber-500/20 text-white"
                      />
                      <select
                        value={newMenuCategory}
                        onChange={(e: any) => setNewMenuCategory(e.target.value)}
                        className="p-2 rounded-lg bg-black border border-amber-500/20 text-white"
                      >
                        <option value="Starters">Starters</option>
                        <option value="Royal Main Course">Royal Main Course</option>
                        <option value="Live Counters">Live Counters</option>
                        <option value="Desserts & Sweets">Desserts & Sweets</option>
                      </select>
                      <input
                        type="number"
                        placeholder="Price / Plate"
                        value={newMenuPrice}
                        onChange={(e) => setNewMenuPrice(Number(e.target.value))}
                        className="p-2 rounded-lg bg-black border border-amber-500/20 text-white"
                      />
                      <select
                        value={newMenuDietary}
                        onChange={(e: any) => setNewMenuDietary(e.target.value)}
                        className="p-2 rounded-lg bg-black border border-amber-500/20 text-white"
                      >
                        <option value="veg">Pure Veg</option>
                        <option value="non-veg">Non-Veg</option>
                        <option value="vegan">Vegan</option>
                      </select>
                    </div>
                    <textarea
                      placeholder="Dish description & ingredient story..."
                      rows={2}
                      value={newMenuDesc}
                      onChange={(e) => setNewMenuDesc(e.target.value)}
                      className="w-full p-2 rounded-lg bg-black border border-amber-500/20 text-white text-xs"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2 rounded-lg bg-amber-500 text-black font-bold text-xs uppercase"
                    >
                      Add Dish to Live Menu
                    </button>
                  </form>

                  {/* Menu List */}
                  <div className="space-y-2">
                    {menuItems.map((item) => (
                      <div key={item.id} className="p-3 rounded-lg bg-neutral-900 border border-amber-500/10 flex items-center justify-between text-xs">
                        <div>
                          <strong className="text-white block">{item.name} ({item.category})</strong>
                          <span className="text-gray-400">₹{item.pricePerPlate} / plate • {item.dietary}</span>
                        </div>
                        <button
                          onClick={() => handleDeleteMenuItem(item.id)}
                          className="p-2 text-red-400 hover:text-red-300"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 4: GALLERY & REELS */}
              {activeTab === 'gallery' && (
                <div className="space-y-6">
                  <form onSubmit={handleAddMedia} className="p-4 rounded-xl bg-neutral-900 border border-amber-500/30 space-y-3">
                    <h5 className="font-serif font-bold text-sm text-amber-300">Upload Media / Reel Video URL</h5>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-xs">
                      <input
                        type="text"
                        placeholder="Title"
                        required
                        value={newMediaTitle}
                        onChange={(e) => setNewMediaTitle(e.target.value)}
                        className="p-2 rounded-lg bg-black border border-amber-500/20 text-white"
                      />
                      <select
                        value={newMediaCat}
                        onChange={(e: any) => setNewMediaCat(e.target.value)}
                        className="p-2 rounded-lg bg-black border border-amber-500/20 text-white"
                      >
                        <option value="Weddings">Weddings</option>
                        <option value="Plating Art">Plating Art</option>
                        <option value="Reels">Reels</option>
                      </select>
                      <select
                        value={newMediaType}
                        onChange={(e: any) => setNewMediaType(e.target.value)}
                        className="p-2 rounded-lg bg-black border border-amber-500/20 text-white"
                      >
                        <option value="IMAGE">Image</option>
                        <option value="VIDEO">Video Reel</option>
                      </select>
                    </div>
                    <input
                      type="text"
                      placeholder="Media URL (e.g. mp4 or image link)"
                      value={newMediaUrl}
                      onChange={(e) => setNewMediaUrl(e.target.value)}
                      className="w-full p-2 rounded-lg bg-black border border-amber-500/20 text-white text-xs"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2 rounded-lg bg-amber-500 text-black font-bold text-xs uppercase"
                    >
                      Publish Media Item
                    </button>
                  </form>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
