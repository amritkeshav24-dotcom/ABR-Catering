export type MealCategory = 'Starters' | 'Royal Main Course' | 'Live Counters' | 'Desserts & Sweets' | 'Mocktails & Beverages' | 'Curated Packages';

export type DietaryType = 'veg' | 'non-veg' | 'vegan' | 'gluten-free';

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  pricePerPlate: number;
  category: MealCategory;
  dietary: DietaryType;
  imageUrl: string;
  isPopular?: boolean;
  isSpecialty?: boolean;
  spiciness?: 1 | 2 | 3;
}

export interface CateringPackage {
  id: string;
  name: string;
  tagline: string;
  pricePerPlate: number;
  minGuests: number;
  includedItemsCount: {
    starters: number;
    mains: number;
    liveCounters: number;
    desserts: number;
    beverages: number;
  };
  highlights: string[];
  recommendedFor: string;
  isPopular?: boolean;
}

export type BookingStatus = 'PENDING' | 'CONFIRMED' | 'COMPLETED' | 'CANCELLED';
export type PaymentStatus = 'PENDING' | 'DEPOSIT_PAID' | 'FULL_PAID' | 'REFUNDED';

export interface Booking {
  id: string;
  customerName: string;
  email: string;
  phone: string;
  eventType: 'Wedding' | 'Corporate Gala' | 'Private Party' | 'Anniversary' | 'Destination Event' | 'Other';
  eventDate: string;
  guestCount: number;
  venueLocation: string;
  selectedPackageId?: string;
  customMenuIds?: string[];
  totalEstimate: number;
  depositAmount: number;
  status: BookingStatus;
  paymentStatus: PaymentStatus;
  razorpayOrderId?: string;
  razorpayPaymentId?: string;
  specialInstructions?: string;
  createdAt: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'Weddings' | 'Corporate' | 'Plating Art' | 'Live Cooking' | 'Reels';
  mediaType: 'IMAGE' | 'VIDEO';
  mediaUrl: string;
  thumbnailUrl: string;
  caption?: string;
  likesCount: number;
  duration?: string; // for reels
  aspectRatio?: 'portrait' | 'landscape';
}

export interface CustomerReview {
  id: string;
  customerName: string;
  eventType: string;
  rating: number;
  comment: string;
  date: string;
  isApproved: boolean;
  isFeatured: boolean;
  avatarUrl?: string;
  verifiedEvent?: boolean;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  suggestedActions?: { label: string; action: string; payload?: any }[];
}

export interface ChatSession {
  id: string;
  customerName?: string;
  phone?: string;
  lastActive: string;
  messages: ChatMessage[];
}

export interface AdminStats {
  totalRevenue: number;
  activeBookingsCount: number;
  pendingInquiriesCount: number;
  totalMenuItems: number;
  averageRating: number;
}
