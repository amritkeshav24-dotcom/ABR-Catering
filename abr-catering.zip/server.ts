import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import { INITIAL_MENU_ITEMS, INITIAL_PACKAGES, INITIAL_BOOKINGS, INITIAL_GALLERY, INITIAL_REVIEWS } from './src/data/initialData.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// In-Memory Data Stores initialized with seed data
let menuItems = [...INITIAL_MENU_ITEMS];
let packages = [...INITIAL_PACKAGES];
let bookings = [...INITIAL_BOOKINGS];
let galleryItems = [...INITIAL_GALLERY];
let reviews = [...INITIAL_REVIEWS];
let chatSessions: any[] = [];

// Gemini Client initialization (Server-side only)
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn('GEMINI_API_KEY is not defined. AI Chatbot fallback response will be used.');
    }
    aiClient = new GoogleGenAI({
      apiKey: apiKey || 'DUMMY_KEY',
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// ================= API ROUTES ================= //

// 1. AI Chatbot API Endpoint (Gemini Powered)
app.post('/api/chat', async (req, res) => {
  try {
    const { messages, sessionId, userLanguage } = req.body;
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'Invalid messages format' });
    }

    const lastUserMsg = messages[messages.length - 1]?.content || '';

    // Create live knowledge base context from current database
    const menuContext = menuItems.map(m => `- ${m.name} (${m.category}): ₹${m.pricePerPlate}/plate [${m.dietary}]. ${m.description}`).join('\n');
    const pkgContext = packages.map(p => `- ${p.name}: ₹${p.pricePerPlate}/plate (Min ${p.minGuests} guests). Includes ${p.includedItemsCount.starters} starters, ${p.includedItemsCount.mains} mains, ${p.includedItemsCount.liveCounters} live counters.`).join('\n');

    const systemInstruction = `
You are the Luxury AI Concierge for "ABR Catering" - India's premier royal event catering brand.
Your name is "ABR Royal Assistant".
Your tone is remarkably polite, elegant, warm, royal, and highly helpful.

KNOWLEDGE BASE & LIVE MENU DATA:
--------------------------------
${menuContext}

CURATED PACKAGES:
${pkgContext}

KEY BRAND RULES & POLICIES:
- Minimum booking size: 50 guests.
- Pricing structure: Per plate pricing covers complete catering setup, warmers, cutlery, uniformed service staff, and cleanup.
- Customizations: We accommodate all dietary needs (Jain, Vegan, Pure Veg, Halal, Gluten-Free).
- Booking Deposit: A nominal token deposit (approx 10% or ₹5,000 to ₹50,000 depending on event size) secures the date.

RESPONSE INSTRUCTIONS:
1. SUPPORT LANGUAGE: Respond in the user's preferred language (English, Hindi, or Hinglish seamlessly). If the user writes in Hindi or Hinglish (e.g. "muje 200 logon ke liye menu batao"), reply warmly in polite Hinglish/Hindi!
2. PACKAGE RECOMMENDATIONS: If the user provides a guest count or budget (e.g. "200 guests for wedding"), calculate estimated per-plate costs and recommend either the "Classic Luxury Package" (₹950/plate) or "Royal Heritage Feast" (₹1450/plate).
3. BOOKING CONVERSION: Always invite them to click the "Book Now" button on screen or offer to transfer their inquiry directly to our WhatsApp (+91 98765 43210).
4. KEEP IT ELEGANT: Use words like "Royal", "Exquisite", "Gourmet", "Feast", "Grand Celebration". Avoid dry robotic answers.
`;

    if (process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY') {
      const ai = getGeminiClient();
      
      // Convert conversation history into prompt format for Gemini
      const conversationPrompt = messages.map(m => `${m.role === 'user' ? 'User' : 'Assistant'}: ${m.content}`).join('\n\n');
      
      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: conversationPrompt,
        config: {
          systemInstruction: systemInstruction,
          temperature: 0.7,
        },
      });

      const replyText = response.text || 'It would be our honor to assist with your catering needs. Please feel free to book directly or contact us on WhatsApp!';

      return res.json({
        content: replyText,
        sessionId: sessionId || `session_${Date.now()}`
      });
    } else {
      // Intelligent fallback if API key is in placeholder state
      let replyText = "Namaste & Welcome to ABR Catering! ";
      const lowerMsg = lastUserMsg.toLowerCase();
      
      if (lowerMsg.includes('price') || lowerMsg.includes('cost') || lowerMsg.includes('रेट') || lowerMsg.includes('budget') || lowerMsg.includes('package')) {
        replyText += "Our curated Royal Catering Packages start from ₹950/plate for Classic Galas, ₹1,450/plate for Royal Heritage Weddings, and ₹2,200/plate for Imperial Destination Events. Would you like to check custom date availability or book a menu tasting?";
      } else if (lowerMsg.includes('veg') || lowerMsg.includes('paneer') || lowerMsg.includes('menu') || lowerMsg.includes('biryani')) {
        replyText += "We offer a regal selection of over 50+ delicacies including Zafrani Galouti Kebabs, Truffle Paneer Tikka, Dum Pukht Shahi Biryani, and Live Molecular Nitrogen Chaat stations. You can explore the full interactive menu right on this page!";
      } else if (lowerMsg.includes('book') || lowerMsg.includes('date') || lowerMsg.includes('contact') || lowerMsg.includes('whatsapp')) {
        replyText += "You can instantly reserve your event date using our online 'Book Now' system with Razorpay deposit protection, or chat directly with our Catering Manager on WhatsApp (+91 98765 43210)!";
      } else {
        replyText += "It is our absolute pleasure to craft an exquisite culinary experience for your celebration. How many guests are you expecting for your special occasion?";
      }

      return res.json({
        content: replyText,
        sessionId: sessionId || `session_${Date.now()}`
      });
    }
  } catch (error: any) {
    console.error('Error in /api/chat:', error);
    res.status(500).json({
      error: 'AI Concierge service temporarily unavailable',
      fallback: 'Namaste! Please connect with our Royal Event Manager on WhatsApp at +91 98765 43210 for immediate assistance.'
    });
  }
});

// 2. Menu APIs
app.get('/api/menu', (req, res) => {
  res.json({ items: menuItems, packages: packages });
});

app.post('/api/menu', (req, res) => {
  const newItem = {
    id: `m_${Date.now()}`,
    ...req.body,
    pricePerPlate: Number(req.body.pricePerPlate) || 300
  };
  menuItems.unshift(newItem);
  res.status(201).json(newItem);
});

app.put('/api/menu/:id', (req, res) => {
  const index = menuItems.findIndex(i => i.id === req.params.id);
  if (index !== -1) {
    menuItems[index] = { ...menuItems[index], ...req.body };
    return res.json(menuItems[index]);
  }
  res.status(404).json({ error: 'Item not found' });
});

app.delete('/api/menu/:id', (req, res) => {
  menuItems = menuItems.filter(i => i.id !== req.params.id);
  res.json({ success: true, id: req.params.id });
});

// 3. Booking & Payment APIs
app.get('/api/bookings', (req, res) => {
  res.json(bookings);
});

app.post('/api/bookings/create-order', (req, res) => {
  const { customerName, email, phone, eventType, eventDate, guestCount, venueLocation, totalEstimate, depositAmount, specialInstructions } = req.body;
  
  const bookingId = `ABR-2026-${Math.floor(1000 + Math.random() * 9000)}`;
  const orderId = `order_${Math.random().toString(36).substring(2, 11).toUpperCase()}`;

  const newBooking = {
    id: bookingId,
    customerName: customerName || 'Valued Guest',
    email: email || '',
    phone: phone || '',
    eventType: eventType || 'Wedding',
    eventDate: eventDate || new Date().toISOString().split('T')[0],
    guestCount: Number(guestCount) || 100,
    venueLocation: venueLocation || 'Main Ballroom',
    totalEstimate: Number(totalEstimate) || 100000,
    depositAmount: Number(depositAmount) || 10000,
    status: 'PENDING',
    paymentStatus: 'PENDING',
    razorpayOrderId: orderId,
    specialInstructions: specialInstructions || '',
    createdAt: new Date().toISOString()
  };

  bookings.unshift(newBooking);

  res.json({
    booking: newBooking,
    razorpayOrderId: orderId,
    amountInPaise: (newBooking.depositAmount || 10000) * 100,
    currency: 'INR',
    keyId: process.env.RAZORPAY_KEY_ID || 'rzp_test_abrcatering2026'
  });
});

app.post('/api/bookings/verify', (req, res) => {
  const { razorpayOrderId, razorpayPaymentId, bookingId } = req.body;

  const bookingIndex = bookings.findIndex(b => b.id === bookingId || b.razorpayOrderId === razorpayOrderId);
  if (bookingIndex !== -1) {
    bookings[bookingIndex].status = 'CONFIRMED';
    bookings[bookingIndex].paymentStatus = 'DEPOSIT_PAID';
    bookings[bookingIndex].razorpayPaymentId = razorpayPaymentId || `pay_${Date.now()}`;

    return res.json({
      success: true,
      message: 'Payment verified and booking confirmed!',
      booking: bookings[bookingIndex],
      whatsappNotificationSent: true
    });
  }

  res.status(400).json({ error: 'Booking record not found' });
});

app.patch('/api/bookings/:id', (req, res) => {
  const index = bookings.findIndex(b => b.id === req.params.id);
  if (index !== -1) {
    bookings[index] = { ...bookings[index], ...req.body };
    return res.json(bookings[index]);
  }
  res.status(404).json({ error: 'Booking not found' });
});

// 4. Gallery & Reels APIs
app.get('/api/gallery', (req, res) => {
  res.json(galleryItems);
});

app.post('/api/gallery', (req, res) => {
  const newItem = {
    id: `g_${Date.now()}`,
    ...req.body,
    likesCount: 0
  };
  galleryItems.unshift(newItem);
  res.status(201).json(newItem);
});

app.delete('/api/gallery/:id', (req, res) => {
  galleryItems = galleryItems.filter(g => g.id !== req.params.id);
  res.json({ success: true, id: req.params.id });
});

// 5. Customer Reviews APIs
app.get('/api/reviews', (req, res) => {
  res.json(reviews);
});

app.post('/api/reviews', (req, res) => {
  const newReview = {
    id: `rev_${Date.now()}`,
    customerName: req.body.customerName || 'Anonymous Guest',
    eventType: req.body.eventType || 'Event Guest',
    rating: Number(req.body.rating) || 5,
    comment: req.body.comment || '',
    date: 'Just Now',
    isApproved: true,
    isFeatured: false,
    verifiedEvent: true
  };
  reviews.unshift(newReview);
  res.status(201).json(newReview);
});

// 6. Admin Analytics Stats API
app.get('/api/stats', (req, res) => {
  const totalRevenue = bookings
    .filter(b => b.paymentStatus === 'DEPOSIT_PAID' || b.paymentStatus === 'FULL_PAID')
    .reduce((sum, b) => sum + (b.totalEstimate || 0), 0);

  const activeBookingsCount = bookings.filter(b => b.status === 'CONFIRMED').length;
  const pendingInquiriesCount = bookings.filter(b => b.status === 'PENDING').length;

  res.json({
    totalRevenue,
    activeBookingsCount,
    pendingInquiriesCount,
    totalMenuItems: menuItems.length,
    averageRating: 4.9
  });
});

// ================= VITE MIDDLEWARE ================= //
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ABR Catering Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
